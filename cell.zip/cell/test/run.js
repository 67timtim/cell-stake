// node --test test/  (or: node test/run.js)
import { test } from 'node:test';
import assert from 'node:assert';
import { tests } from './suite.js';
for (const t of tests) test(t.name, async () => { await t.fn(); assert.ok(true); });
