// Environment-agnostic test suite for the shared simulation, economy and host.
// Runs in Node (test/run.js) and in a browser (test/index.html).
import { CONFIG as C } from '../client/shared/config.js';
import { World, radiusOf } from '../client/shared/sim.js';
import { Room } from '../client/shared/room.js';
import { GameHost } from '../client/shared/host.js';
import { newAccount, enterRound, settleExtraction, settleDeath, applyDailyAllowance, payoutFor, stakeFor } from '../client/shared/economy.js';
import { cleanName } from '../client/shared/profanity.js';
import { updateBots } from '../client/shared/bots.js';

const DT = 1 / C.TICK_RATE;
function assert(cond, msg) { if (!cond) throw new Error('ASSERT: ' + msg); }
function near(a, b, eps, msg) { assert(Math.abs(a - b) <= eps, `${msg} (got ${a}, want ${b}±${eps})`); }
function stepN(w, n, pre) { for (let i = 0; i < n; i++) { if (pre) pre(i); w.step(DT); } }
class MemStore { constructor() { this.m = new Map(); } async get(t) { const v = this.m.get(t); return v ? JSON.parse(JSON.stringify(v)) : null; } async set(t, a) { this.m.set(t, JSON.parse(JSON.stringify(a))); } }
const tick = () => new Promise(r => setTimeout(r, 0));

export const tests = [];
const test = (name, fn) => tests.push({ name, fn });

// ---- sim -----------------------------------------------------------------
test('pellets: cell moving over pellets gains mass', () => {
  const w = new World({ seed: 1 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const c = w.cells.get([...p.cells][0]);
  // Plant pellets on a line ahead of the cell
  for (let i = 1; i <= 20; i++) { const pl = { id: w.id(), x: c.x + i * 15, y: c.y, c: 0 }; w.pellets.set(pl.id, pl); w.pelletGrid.insert(pl); }
  w.setInput(1, { x: c.x + 2000, y: c.y });
  stepN(w, 60);
  assert(p.mass > C.START_MASS + 10, 'gained mass from pellets: ' + p.mass);
  assert(w.pellets.size >= w.pelletTarget - 1, 'pellets respawn to target');
});

test('eating: bigger cell absorbs smaller, gains 85%, kill counted for humans only', () => {
  const w = new World({ seed: 2 });
  const big = w.addPlayer({ id: 1, name: 'big' });
  const small = w.addPlayer({ id: 2, name: 'small' });
  const bot = w.addPlayer({ id: 3, name: 'bot', bot: true });
  const bc = w.cells.get([...big.cells][0]);
  bc.mass = 200; bc.r = radiusOf(200); bc.x = 3000; bc.y = 3000;
  const sc = w.cells.get([...small.cells][0]); sc.x = 3000 + 5; sc.y = 3000;
  const tc = w.cells.get([...bot.cells][0]); tc.x = 3000; tc.y = 3000 + 5;
  for (const p of [big, small, bot]) p.spawnProtUntil = 0;
  w.setInput(1, { x: 3000, y: 3000 });
  stepN(w, 3);
  assert(!small.alive && !bot.alive, 'both prey dead');
  near(big.mass, 200 + 30 * C.EAT_GAIN * 2, 1.5, 'gain 85% of each');
  assert(big.kills === 1, 'only the human counts as a kill: ' + big.kills);
  const deaths = w.drainEvents().filter(e => e.t === 'death');
  assert(deaths.length === 2 && deaths.every(e => e.by === 1), 'death events credit killer');
});

test('eating: ratio rule — 1.2x is not enough', () => {
  const w = new World({ seed: 3 });
  const a = w.addPlayer({ id: 1, name: 'a' }), b = w.addPlayer({ id: 2, name: 'b' });
  const ac = w.cells.get([...a.cells][0]), bc = w.cells.get([...b.cells][0]);
  ac.mass = 36; ac.r = radiusOf(36); ac.x = 3000; ac.y = 3000; bc.x = 3000; bc.y = 3000; bc.mass = 30;
  a.spawnProtUntil = b.spawnProtUntil = 0;
  w.setInput(1, { x: 3000, y: 3000 }); w.setInput(2, { x: 3000, y: 3000 });
  stepN(w, 5);
  assert(a.alive && b.alive, 'neither eaten at 1.2x');
});

test('spawn protection: cannot eat or be eaten for 5s', () => {
  const w = new World({ seed: 4 });
  const a = w.addPlayer({ id: 1, name: 'a' }), b = w.addPlayer({ id: 2, name: 'b' });
  const ac = w.cells.get([...a.cells][0]), bc = w.cells.get([...b.cells][0]);
  ac.mass = 500; ac.r = radiusOf(500); ac.x = bc.x = 3000; ac.y = bc.y = 3000;
  w.setInput(1, { x: 3000, y: 3000 }); w.setInput(2, { x: 3000, y: 3000 });
  stepN(w, 20);
  assert(b.alive, 'protected while shielded');
  stepN(w, C.TICK_RATE * 5);
  assert(!b.alive, 'eaten after protection ends');
});

test('split: halves mass, max 8 cells, remerges later', () => {
  const w = new World({ seed: 5 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const c = w.cells.get([...p.cells][0]); c.mass = 400; c.r = radiusOf(400);
  w.setInput(1, { x: c.x + 500, y: c.y, split: true });
  w.step(DT);
  assert(p.cells.size === 2, 'two cells after split');
  near(p.mass, 400, 0.5, 'mass conserved');
  for (let i = 0; i < 5; i++) { w.setInput(1, { x: c.x + 500, y: c.y, split: true }); w.step(DT); }
  assert(p.cells.size <= C.MAX_CELLS, 'max cells respected: ' + p.cells.size);
  // Move target onto the centroid so cells converge, and wait for merge timers.
  const merge = C.MERGE_BASE_SEC + 400 * C.MERGE_PER_MASS_SEC + 5;
  stepN(w, Math.ceil(merge * C.TICK_RATE), () => w.setInput(1, { x: p.cx, y: p.cy }));
  assert(p.cells.size < 8, 'cells remerge over time: ' + p.cells.size);
});

test('eject: costs 18, spawns 15-mass blob, others can eat it', () => {
  const w = new World({ seed: 6 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const c = w.cells.get([...p.cells][0]); c.mass = 100; c.r = radiusOf(100);
  w.setInput(1, { x: c.x + 300, y: c.y, eject: true });
  w.step(DT);
  near(p.mass, 100 - C.EJECT_COST, 0.5, 'eject cost');
  assert(w.ejected.size === 1, 'one blob');
  const e = [...w.ejected.values()][0]; assert(e.mass === C.EJECT_MASS, 'blob mass');
});

test('decay: mass above 200 shrinks at 0.2%/s', () => {
  const w = new World({ seed: 7 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const c = w.cells.get([...p.cells][0]); c.mass = 1000; c.r = radiusOf(1000); c.x = 3000; c.y = 3000;
  w.setInput(1, { x: 3000, y: 3000 });
  // Clear pellets so nothing is eaten
  w.pellets.clear(); w.pelletGrid.clear(); w.pelletTarget = 0;
  stepN(w, C.TICK_RATE * 10);
  near(p.mass, 1000 * Math.pow(1 - C.DECAY_RATE * DT, C.TICK_RATE * 10), 1, 'decay after 10s');
});

test('multiplier: +0.1 per 30s, +0.2 per 100 peak mass, cap, high tier x1.5', () => {
  const w = new World({ seed: 8 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const c = w.cells.get([...p.cells][0]); c.x = 3000; c.y = 3000;
  w.setInput(1, { x: 3000, y: 3000 });
  w.pellets.clear(); w.pelletGrid.clear(); w.pelletTarget = 0;
  stepN(w, C.TICK_RATE * 30 + 1, () => { p.lastInputAt = w.time; });
  near(p.mult, 0.1, 1e-6, '30s survival');
  c.mass = 245; stepN(w, 1); near(p.mult, 0.5, 1e-6, "+200 peak mass");
  c.mass = 30; stepN(w, 1); near(p.mult, 0.5, 1e-6, 'peak, not current');
  p.kills = 20; stepN(w, 1); near(p.mult, C.MULT_CAP, 1e-6, 'capped');
  p.streak = 2; stepN(w, 1); near(p.mult, C.MULT_CAP + 2 * C.STREAK_CAP_BONUS, 1e-6, 'streak raises cap');
  const wh = new World({ seed: 9, tier: 'high' });
  const q = wh.addPlayer({ id: 1, name: 'a' });
  const qc = wh.cells.get([...q.cells][0]); qc.x = 3000; qc.y = 3000; wh.setInput(1, { x: 3000, y: 3000 });
  wh.pellets.clear(); wh.pelletGrid.clear(); wh.pelletTarget = 0;
  stepN(wh, C.TICK_RATE * 30 + 1, () => { q.lastInputAt = wh.time; });
  near(q.mult, 0.15, 1e-6, 'high roller grows 1.5x faster');
});

test('extraction: 3s uninterrupted inside a ring, leaving resets', () => {
  const w = new World({ seed: 10 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  const ring = w.rings[0];
  const c = w.cells.get([...p.cells][0]); c.x = ring.x; c.y = ring.y;
  w.setInput(1, { x: ring.x, y: ring.y });
  stepN(w, C.TICK_RATE * 2);
  assert(p.alive && p.extractT > 1.5, 'channeling');
  // Step out
  c.x = ring.x + ring.r + 50; w.setInput(1, { x: c.x, y: c.y });
  stepN(w, 2);
  assert(p.extractT === 0 && p.extractRing === -1, 'reset on leaving');
  c.x = ring.x; w.setInput(1, { x: ring.x, y: ring.y });
  stepN(w, C.TICK_RATE * 3 + 2);
  assert(!p.alive, 'extracted');
  const ev = w.drainEvents().find(e => e.t === 'extract');
  assert(ev && ev.p === 1, 'extract event');
});

test('AFK: no input for 60s forfeits', () => {
  const w = new World({ seed: 11 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  stepN(w, C.TICK_RATE * 61);
  assert(!p.alive, 'removed');
  assert(w.drainEvents().some(e => e.t === 'death' && e.reason === 'afk'), 'afk death event');
});

test('input validation: bad coordinates ignored / clamped', () => {
  const w = new World({ seed: 12 });
  const p = w.addPlayer({ id: 1, name: 'a' });
  w.setInput(1, { x: 1e9, y: -1e9 });
  assert(p.target.x === C.MAP_SIZE && p.target.y === 0, 'clamped');
  w.setInput(1, { x: NaN, y: 'x' });
  assert(p.target.x === C.MAP_SIZE, 'NaN ignored');
});

// ---- economy -------------------------------------------------------------
test('economy: stake, floor, payout, streaks, allowance', () => {
  const a = newAccount(0);
  assert(a.bank === C.START_BANK, 'start bank');
  assert(stakeFor(500, 10) === 50 && stakeFor(120, 10) === 50 && stakeFor(100, 100) === 100, 'stakeFor');
  const { stake, tier } = enterRound(a, 50);
  assert(stake === 250 && tier === 'high' && a.bank === 250, 'enter 50%');
  const r = settleExtraction(a, stake, 2.0);
  assert(r.payout === 500 && a.bank === 750 && a.streak === 1, 'payout & streak');
  const r2 = settleExtraction(a, 100, 1.5);
  assert(r2.payout === payoutFor(100, 1.5, 1) && r2.payout === 165, 'streak +10% payout');
  const r3 = settleExtraction(a, 100, 0.5);
  assert(a.streak === 2 && r3.payout === 60, 'unprofitable extraction keeps streak, pays less');
  settleDeath(a, 100, 3);
  assert(a.streak === 0 && a.stats.playersEaten === 3, 'death resets streak');
  const b = newAccount(0); b.bank = 100; enterRound(b, 100);
  assert(b.bank === C.BANK_FLOOR, 'mercy floor');
  assert(applyDailyAllowance(b, C.DAILY_MS - 1) === 0, 'no allowance early');
  assert(applyDailyAllowance(b, C.DAILY_MS) === C.DAILY_ALLOWANCE && b.bank === 400, 'allowance after 24h');
});

test('profanity filter', () => {
  assert(cleanName('sh1t') === 'cell' && cleanName('  Nova9 ') === 'Nova9' && cleanName('') === 'cell', 'filter');
  assert(cleanName('averyveryverylongname12345').length <= 14, 'length');
});

// ---- room / bots ---------------------------------------------------------
test('room: bots fill to 15, survive 60s of simulation, respawn after death', () => {
  const room = new Room({ tier: 'casual', seed: 20 });
  assert(room.aliveCount() === C.MIN_ENTITIES, 'filled: ' + room.aliveCount());
  for (let i = 0; i < C.TICK_RATE * 60; i++) room.tick();
  const alive = room.aliveCount();
  assert(alive >= C.MIN_ENTITIES - 3 && alive <= C.MIN_ENTITIES, 'bots maintained: ' + alive);
  let bigMass = 0; for (const p of room.world.players.values()) bigMass = Math.max(bigMass, p.mass);
  assert(bigMass > C.START_MASS * 2, 'bots actually eat: ' + bigMass);
});

test('room: snapshot only contains entities in the viewer AOI; pellet deltas are consistent', () => {
  const msgs = [];
  const room = new Room({ tier: 'casual', seed: 21, send: (id, m) => msgs.push([id, m]) });
  const id = room.join({ name: 'me', skin: 0, stake: 50, streak: 0 });
  room.resendJoin(id);
  const known = new Set();
  for (let i = 0; i < 40; i++) room.tick();
  const p = room.world.players.get(id);
  for (const [, m] of msgs) {
    if (m.t !== 'snap') continue;
    for (let i = 0; i < m.pa.length; i += 4) { assert(!known.has(m.pa[i]), 'pellet added twice'); known.add(m.pa[i]); }
    for (const r of m.pr) { assert(known.has(r), 'removed unknown pellet'); known.delete(r); }
  }
  const last = msgs.filter(([, m]) => m.t === 'snap').pop()[1];
  const half = C.MAP_SIZE; // sanity: no cell farther than the AOI box
  for (let i = 0; i < last.c.length; i += 6) {
    assert(Math.abs(last.c[i + 2] - p.cx) < half && Math.abs(last.c[i + 3] - p.cy) < half, 'cell in AOI');
  }
  assert(last.me && typeof last.me.mult === 'number', 'me block present');
});

// ---- host / protocol -----------------------------------------------------
function fakeConn() { const c = { out: [], send(m) { c.out.push(m); }, close() { c.closed = true; }, session: null }; return c; }
function last(c, t) { for (let i = c.out.length - 1; i >= 0; i--) if (c.out[i].t === t) return c.out[i]; return null; }

test('host: hello/join/result flow, bank only changes server-side', async () => {
  const store = new MemStore();
  const host = new GameHost({ storage: store });
  const c = fakeConn();
  await host.handle(c, { t: 'hello', token: 'tok_12345678', name: 'Tester' });
  const w = last(c, 'welcome');
  assert(w && w.account.bank === C.START_BANK && w.name === 'Tester', 'welcome');
  await host.handle(c, { t: 'join', risk: 33 });
  assert(last(c, 'err') && last(c, 'err').code === 'risk', 'invalid risk rejected');
  await host.handle(c, { t: 'join', risk: 25 });
  const j = last(c, 'joined');
  assert(j && j.stake === 125 && j.tier === 'casual', 'joined with stake 125');
  assert(last(c, 'account').account.bank === 375, 'stake deducted');
  await host.handle(c, { t: 'join', risk: 10 });
  assert(last(c, 'err').code === 'inround', 'cannot double join');
  // No message can set bank
  await host.handle(c, { t: 'bank', bank: 999999 });
  await host.handle(c, { t: 'account', account: { bank: 999999 } });
  assert(c.session.acct.bank === 375, 'bank untouched by tampered messages');
  // Locked skin rejected
  await host.handle(c, { t: 'skin', skin: 6 });
  assert(last(c, 'err').code === 'skin' && c.session.acct.skin === 0, 'locked skin rejected');
  // Teleport the player into a ring server-side and let it extract
  const room = host.rooms.get(c.session.roomId);
  const p = room.world.players.get(c.session.playerId);
  const ring = room.world.rings[0];
  for (const cid of p.cells) { const cell = room.world.cells.get(cid); cell.x = ring.x; cell.y = ring.y; }
  for (let i = 0; i < C.TICK_RATE * 4; i++) { await host.handle(c, { t: 'in', q: i, x: ring.x, y: ring.y }); host.tickAll(); }
  const r = last(c, 'result');
  assert(r && r.result.kind === 'extract', 'extract result delivered');
  assert(r.account.bank === 375 + Math.floor(125 * r.result.mult), 'payout applied: ' + r.account.bank);
  assert(c.session.roomId === null, 'back to menu');
  await tick();
  const saved = await store.get('tok_12345678');
  assert(saved && saved.bank === r.account.bank, 'persisted');
});

test('host: death forfeits stake; leave forfeits; one session per token', async () => {
  const host = new GameHost({ storage: new MemStore() });
  const c = fakeConn();
  await host.handle(c, { t: 'hello', token: 'tok_abcdefgh' });
  await host.handle(c, { t: 'join', risk: 10 });
  await host.handle(c, { t: 'leave' });
  const r = last(c, 'result');
  assert(r && r.result.kind === 'death' && r.result.reason === 'left' && r.account.bank === 450, 'leave = forfeit');
  const c2 = fakeConn();
  await host.handle(c2, { t: 'hello', token: 'tok_abcdefgh' });
  assert(c.closed && last(c, 'kicked'), 'old connection kicked');
  assert(last(c2, 'welcome').account.bank === 450, 'same account');
});

test('host: reconnect mid-round resumes the same player', async () => {
  const host = new GameHost({ storage: new MemStore() });
  const c = fakeConn();
  await host.handle(c, { t: 'hello', token: 'tok_reconnect1' });
  await host.handle(c, { t: 'join', risk: 10 });
  const pid = c.session.playerId;
  host.disconnect(c);
  for (let i = 0; i < 20; i++) host.tickAll();
  const c2 = fakeConn();
  await host.handle(c2, { t: 'hello', token: 'tok_reconnect1' });
  const j = last(c2, 'joined');
  assert(j && j.id === pid, 'rejoined same player id');
  host.tickAll();
  assert(last(c2, 'snap'), 'snapshots flow again');
});

test('host: input rate limit clamps to INPUT_RATE/s', async () => {
  let now = 0;
  const host = new GameHost({ storage: new MemStore(), now: () => now });
  const c = fakeConn();
  await host.handle(c, { t: 'hello', token: 'tok_ratelimit1' });
  await host.handle(c, { t: 'join', risk: 10 });
  const room = host.rooms.get(c.session.roomId);
  const p = room.world.players.get(c.session.playerId);
  for (let i = 0; i < 200; i++) await host.handle(c, { t: 'in', q: i, x: 100, y: 100 });
  assert(p.lastSeq < 60, 'excess inputs dropped: lastSeq=' + p.lastSeq);
});

test('perf: 40 players + bots, 200 ticks under budget', () => {
  const room = new Room({ tier: 'casual', seed: 30 });
  for (let i = 0; i < 25; i++) room.join({ name: 'p' + i, skin: 0, stake: 50, streak: 0 });
  const t0 = (globalThis.performance || Date).now();
  for (let i = 0; i < 200; i++) room.tick();
  const ms = (globalThis.performance || Date).now() - t0;
  assert(ms / 200 < 25, `tick avg ${(ms / 200).toFixed(2)}ms (must be well under 50ms budget)`);
  return `avg tick ${(ms / 200).toFixed(2)}ms`;
});

export async function runAll(log = console.log) {
  let pass = 0, fail = 0;
  for (const t of tests) {
    try { const info = await t.fn(); pass++; log(`ok   ${t.name}${info ? ' — ' + info : ''}`); }
    catch (e) { fail++; log(`FAIL ${t.name}\n     ${e.message}`); }
  }
  log(`${pass} passed, ${fail} failed`);
  return { pass, fail };
}
