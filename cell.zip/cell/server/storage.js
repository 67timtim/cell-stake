// Server-side persistence behind the GameHost storage interface.
// MVP: one JSON file, debounced writes. Swap for SQLite/Redis/cloud-save by
// implementing the same two methods.
import fs from 'node:fs';
import path from 'node:path';

export class JsonFileStore {
  constructor(file) {
    this.file = file;
    this.data = {};
    this.dirty = false;
    this.timer = null;
    try {
      if (fs.existsSync(file)) this.data = JSON.parse(fs.readFileSync(file, 'utf8')) || {};
    } catch (e) { console.warn('[store] could not read', file, e.message); }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    process.on('SIGINT', () => { this.flushSync(); process.exit(0); });
    process.on('SIGTERM', () => { this.flushSync(); process.exit(0); });
  }
  async get(token) { return this.data[token] ? structuredClone(this.data[token]) : null; }
  async set(token, acct) {
    this.data[token] = structuredClone(acct);
    this.dirty = true;
    if (!this.timer) this.timer = setTimeout(() => this.flush(), 2000);
  }
  flush() {
    this.timer = null;
    if (!this.dirty) return;
    this.dirty = false;
    const tmp = this.file + '.tmp';
    fs.writeFile(tmp, JSON.stringify(this.data), (err) => {
      if (err) { console.warn('[store] write failed', err.message); this.dirty = true; return; }
      fs.rename(tmp, this.file, (e2) => { if (e2) console.warn('[store] rename failed', e2.message); });
    });
  }
  flushSync() {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    try { fs.writeFileSync(this.file, JSON.stringify(this.data)); } catch (e) { console.warn('[store] sync write failed', e.message); }
  }
}

export class MemoryStore {
  constructor() { this.data = new Map(); }
  async get(token) { const v = this.data.get(token); return v ? structuredClone(v) : null; }
  async set(token, acct) { this.data.set(token, structuredClone(acct)); }
}
