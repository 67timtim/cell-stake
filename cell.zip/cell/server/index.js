// CELL — authoritative game server.
//   node server/index.js
// Env: PORT (8080), DATA_FILE (./data/accounts.json), SERVE_CLIENT (1 to also
// serve ../client as static files — handy for a single-service deploy),
// ALLOWED_ORIGINS (comma list; empty = allow all).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import { GameHost } from '../client/shared/host.js';
import { CONFIG as C } from '../client/shared/config.js';
import { JsonFileStore } from './storage.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = +(process.env.PORT || 8080);
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'accounts.json');
const SERVE_CLIENT = process.env.SERVE_CLIENT === '1';
const ALLOWED = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const CLIENT_DIR = path.join(__dirname, '..', 'client');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

const store = new JsonFileStore(DATA_FILE);
const host = new GameHost({ storage: store, log: (...a) => console.warn('[host]', ...a) });
host.startLoop();

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/health') {
    let humans = 0; for (const r of host.rooms.values()) humans += r.humanCount();
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, rooms: host.rooms.size, players: humans, tick: C.TICK_RATE }));
  }
  if (!SERVE_CLIENT) { res.writeHead(404); return res.end('CELL server. Connect via WebSocket at /ws'); }
  let p = decodeURIComponent(url.pathname);
  if (p === '/' || p === '') p = '/index.html';
  const file = path.normalize(path.join(CLIENT_DIR, p));
  if (!file.startsWith(CLIENT_DIR)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 4096 });

wss.on('connection', (ws, req) => {
  const origin = req.headers.origin;
  if (ALLOWED.length && (!origin || !ALLOWED.includes(origin))) { ws.close(1008, 'origin'); return; }
  const conn = {
    send(obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); },
    close() { try { ws.close(); } catch (_) {} },
    session: null, token: null,
    ip: req.socket.remoteAddress,
  };
  let msgCount = 0, msgWindow = Date.now();
  ws.on('message', (data) => {
    // Coarse flood guard: 120 messages / second max per socket.
    const now = Date.now();
    if (now - msgWindow > 1000) { msgWindow = now; msgCount = 0; }
    if (++msgCount > 120) { ws.close(1008, 'flood'); return; }
    let msg;
    try { msg = JSON.parse(data.toString()); } catch (_) { return; }
    host.handle(conn, msg);
  });
  ws.on('close', () => host.disconnect(conn));
  ws.on('error', () => {});
});

// Heartbeat: drop dead sockets.
const hb = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 30000);
wss.on('connection', (ws) => { ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; }); });
wss.on('close', () => clearInterval(hb));

server.listen(PORT, () => {
  console.log(`CELL server listening on :${PORT}  (ws path /ws, tick ${C.TICK_RATE}/s, data ${DATA_FILE}${SERVE_CLIENT ? ', serving client' : ''})`);
});
