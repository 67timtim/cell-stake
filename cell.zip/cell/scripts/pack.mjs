// Build the CrazyGames upload zip: client/ with the production server URL baked in.
//   node scripts/pack.mjs wss://your-server.up.railway.app/ws
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2];
if (!url || !/^wss?:\/\//.test(url)) { console.error('usage: node scripts/pack.mjs wss://HOST/ws'); process.exit(1); }
const out = path.join(root, 'dist', 'crazygames');
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(path.join(root, 'client'), out, { recursive: true, filter: (p) => !p.endsWith('_headers') });
const cfg = path.join(out, 'js', 'serverConfig.js');
fs.writeFileSync(cfg, fs.readFileSync(cfg, 'utf8').replace("export const SERVER_URL = '';", `export const SERVER_URL = '${url}';`));
const zip = path.join(root, 'dist', 'cell-crazygames.zip');
fs.rmSync(zip, { force: true });
execSync(`cd "${out}" && zip -qr "${zip}" .`);
console.log('wrote', zip, '(index.html at zip root, server =', url + ')');
