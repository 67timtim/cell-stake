// AdsInterface — portal SDK seam. The game only ever talks to this object.
// The default implementation is a no-op; the CrazyGames SDK adapter gets
// wired here after Full Launch invite. Both hooks are gated by
// CONFIG.ADS_ENABLED and enforced server-side (daily caps).
export class NoopAds {
  constructor() { this.available = false; }
  async init() { return false; }
  async preloadRewarded() { return false; }
  // Resolves true only if the user watched a rewarded ad to completion.
  async showRewarded(_tag) { return false; }
  async showInterstitial(_tag) { return false; }
  // Portals like to know when gameplay starts/stops (for their own overlays).
  gameplayStart() {}
  gameplayStop() {}
  happyTime() {}
}

export const ads = new NoopAds();
