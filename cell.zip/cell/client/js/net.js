// Transports. The game code speaks one message protocol; underneath it is
// either a WebSocket to the authoritative server or an in-page GameHost
// (offline practice mode: same rules, same bots, bank kept in localStorage).
import { GameHost } from '../shared/host.js';
import { LocalAccountStore } from './storage.js';

export class WsTransport {
  constructor(url) { this.url = url; this.ws = null; this.handlers = { message: [], open: [], close: [] }; this.kind = 'online'; }
  on(ev, fn) { this.handlers[ev].push(fn); return this; }
  emit(ev, a) { for (const fn of this.handlers[ev]) fn(a); }
  connect(timeoutMs = 4000) {
    return new Promise((resolve, reject) => {
      let done = false;
      let ws;
      try { ws = new WebSocket(this.url); } catch (e) { return reject(e); }
      this.ws = ws;
      const timer = setTimeout(() => { if (!done) { done = true; try { ws.close(); } catch (_) {} reject(new Error('timeout')); } }, timeoutMs);
      ws.onopen = () => { if (done) return; done = true; clearTimeout(timer); this.emit('open'); resolve(this); };
      ws.onerror = () => { if (!done) { done = true; clearTimeout(timer); reject(new Error('ws error')); } };
      ws.onclose = () => { this.emit('close'); };
      ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (_) { return; } this.emit('message', m); };
    });
  }
  send(obj) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(obj)); }
  close() { try { this.ws && this.ws.close(); } catch (_) {} }
  get connected() { return !!this.ws && this.ws.readyState === 1; }
}

let sharedHost = null;
export class LocalTransport {
  constructor() {
    this.kind = 'offline';
    this.handlers = { message: [], open: [], close: [] };
    if (!sharedHost) { sharedHost = new GameHost({ storage: new LocalAccountStore(), log: console.warn }); sharedHost.startLoop(); }
    this.host = sharedHost;
    const self = this;
    this.conn = {
      send(m) { self.queue.push(m); if (!self.flushing) { self.flushing = true; queueMicrotask(() => self.flush()); } },
      close() { self.emit('close'); },
    };
    this.queue = []; this.flushing = false;
  }
  on(ev, fn) { this.handlers[ev].push(fn); return this; }
  emit(ev, a) { for (const fn of this.handlers[ev]) fn(a); }
  flush() { this.flushing = false; const q = this.queue; this.queue = []; for (const m of q) this.emit('message', m); }
  async connect() { this.emit('open'); return this; }
  send(obj) { this.host.handle(this.conn, obj); }
  close() { this.host.disconnect(this.conn); }
  get connected() { return true; }
}
