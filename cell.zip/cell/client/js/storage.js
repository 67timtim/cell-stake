// Persistence interface. Everything that touches localStorage goes through
// here so a portal SDK (cloud save / auth) can replace it later without
// touching game code. Two roles:
//   ClientStore  — token, name, settings, first-run flags (always local)
//   AccountStore — the Bank. Used ONLY by offline practice mode; online, the
//                  server owns the account and this is never consulted.
const NS = 'cell.';

function safeGet(k) { try { return localStorage.getItem(NS + k); } catch (_) { return null; } }
function safeSet(k, v) { try { localStorage.setItem(NS + k, v); } catch (_) {} }

export const ClientStore = {
  getJSON(key, def) { const v = safeGet(key); if (v == null) return def; try { return JSON.parse(v); } catch (_) { return def; } },
  setJSON(key, val) { safeSet(key, JSON.stringify(val)); },
  get(key, def = null) { const v = safeGet(key); return v == null ? def : v; },
  set(key, val) { safeSet(key, String(val)); },
  token() {
    let t = this.get('token');
    if (!t) { t = randomToken(); this.set('token', t); }
    return t;
  },
};

export function randomToken() {
  const a = new Uint8Array(24);
  (globalThis.crypto || { getRandomValues: (b) => { for (let i = 0; i < b.length; i++) b[i] = (Math.random() * 256) | 0; } }).getRandomValues(a);
  let s = '';
  const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  for (const b of a) s += alpha[b & 63];
  return s;
}

// GameHost storage interface backed by localStorage (offline mode only).
export class LocalAccountStore {
  async get(token) { return ClientStore.getJSON('acct.' + token, null); }
  async set(token, acct) { ClientStore.setJSON('acct.' + token, acct); }
}
