// Cosmetic-only skins. Index 0 is always unlocked; the rest unlock at Bank
// milestones (CONFIG.SKIN_MILESTONES, in order). Bots draw from the same set.
export const SKINS = [
  { name: 'Slate',      c1: '#5ee6d6', c2: '#1f8fa8', glow: '#5ee6d6', pattern: 'none' },
  { name: 'Ember',      c1: '#ffb15c', c2: '#e0323c', glow: '#ff7a3c', pattern: 'none' },
  { name: 'Ultraviolet',c1: '#c37bff', c2: '#5b2bd6', glow: '#a86bff', pattern: 'ring' },
  { name: 'Acid',       c1: '#d8ff3d', c2: '#2fb54a', glow: '#b8ff3d', pattern: 'dots' },
  { name: 'Glacier',    c1: '#ffffff', c2: '#5cb8ff', glow: '#9fd8ff', pattern: 'stripes' },
  { name: 'Sunset',     c1: '#ffd36b', c2: '#ff4d8d', glow: '#ff7ab0', pattern: 'ring', trail: true },
  { name: 'Nova',       c1: '#fff1a8', c2: '#f5a623', glow: '#ffd24d', pattern: 'star', trail: true },
];

export const PELLET_PALETTE = ['#ff5c8a', '#ffb02e', '#ffe45c', '#7dff6b', '#5ee6d6', '#5cb8ff', '#b47bff', '#ff8a5c'];

// Pre-render one 256x256 sprite per skin: gradient disc + soft glow + outline.
// drawImage() with scaling is far cheaper than building gradients per frame.
const cache = new Map();
export function skinSprite(i) {
  const idx = ((i % SKINS.length) + SKINS.length) % SKINS.length;
  let sp = cache.get(idx);
  if (sp) return sp;
  const S = 256, cx = S / 2, R = 100;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d');
  const s = SKINS[idx];
  // glow
  const glow = g.createRadialGradient(cx, cx, R * 0.85, cx, cx, R * 1.26);
  glow.addColorStop(0, hexA(s.glow, 0.45));
  glow.addColorStop(1, hexA(s.glow, 0));
  g.fillStyle = glow;
  g.fillRect(0, 0, S, S);
  // body
  const grad = g.createRadialGradient(cx - R * 0.35, cx - R * 0.35, R * 0.1, cx, cx, R);
  grad.addColorStop(0, s.c1);
  grad.addColorStop(1, s.c2);
  g.fillStyle = grad;
  g.beginPath(); g.arc(cx, cx, R, 0, Math.PI * 2); g.fill();
  // pattern
  g.save();
  g.beginPath(); g.arc(cx, cx, R, 0, Math.PI * 2); g.clip();
  g.globalAlpha = 0.18; g.fillStyle = '#ffffff'; g.strokeStyle = '#ffffff'; g.lineWidth = 6;
  if (s.pattern === 'ring') { g.beginPath(); g.arc(cx, cx, R * 0.62, 0, Math.PI * 2); g.stroke(); }
  else if (s.pattern === 'dots') { for (let a = 0; a < 8; a++) { const t = a / 8 * Math.PI * 2; g.beginPath(); g.arc(cx + Math.cos(t) * R * 0.6, cx + Math.sin(t) * R * 0.6, 9, 0, Math.PI * 2); g.fill(); } }
  else if (s.pattern === 'stripes') { for (let k = -3; k <= 3; k++) { g.beginPath(); g.moveTo(cx + k * 34 - R, cx - R); g.lineTo(cx + k * 34 + R, cx + R); g.stroke(); } }
  else if (s.pattern === 'star') { g.beginPath(); for (let a = 0; a < 10; a++) { const t = a / 10 * Math.PI * 2 - Math.PI / 2; const rr = a % 2 ? R * 0.28 : R * 0.6; g.lineTo(cx + Math.cos(t) * rr, cx + Math.sin(t) * rr); } g.closePath(); g.fill(); }
  g.restore();
  // outline
  g.globalAlpha = 1; g.lineWidth = 5; g.strokeStyle = 'rgba(0,0,0,0.35)';
  g.beginPath(); g.arc(cx, cx, R - 2.5, 0, Math.PI * 2); g.stroke();
  g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,0.35)';
  g.beginPath(); g.arc(cx, cx, R - 6, 0, Math.PI * 2); g.stroke();
  sp = { canvas: c, scale: S / (2 * R) }; // draw size = 2r * scale
  cache.set(idx, sp);
  return sp;
}

export function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
