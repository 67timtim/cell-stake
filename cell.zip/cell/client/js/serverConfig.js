// Where the client looks for the authoritative server.
// Leave empty to auto-detect: ?server=wss://... query param, else
// ws://localhost:8080 during local dev, else same-origin /ws.
// If nothing answers within a couple of seconds the game runs in OFFLINE
// practice mode (same rules, bots, Bank kept on this device).
export const SERVER_URL = '';

export function resolveServerUrl() {
  const q = new URLSearchParams(location.search).get('server');
  if (q) return q;
  if (SERVER_URL) return SERVER_URL;
  if (location.protocol === 'file:') return 'ws://localhost:8080/ws';
  const wsProto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) return 'ws://localhost:8080/ws';
  return `${wsProto}//${location.host}/ws`;
}
