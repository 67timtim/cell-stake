// CELL — app shell: connection, menu, HUD, overlays, round lifecycle.
import { CONFIG as C, TIER_FOR_RISK } from '../shared/config.js';
import { stakeFor } from '../shared/economy.js';
import { cleanName } from '../shared/profanity.js';
import { WsTransport, LocalTransport } from './net.js';
import { resolveServerUrl } from './serverConfig.js';
import { ClientStore } from './storage.js';
import { Renderer } from './render.js';
import { Input } from './input.js';
import { audio } from './audio.js';
import { GameClient } from './game.js';
import { SKINS, skinSprite } from './skins.js';
import { ads } from './ads.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('en-US');

// ---------------------------------------------------------------------------
// HUD
// ---------------------------------------------------------------------------
const hud = {
  el: $('hud'), lastText: 0,
  roundStart(g) {
    this.el.classList.remove('hidden');
    $('hud-stake').textContent = fmt(g.stake);
    $('hud-hint').classList.remove('hidden');
    $('hud-lb').innerHTML = '';
    setTimeout(() => $('hud-hint').classList.add('hidden'), 9000);
    this._pulseT = 0;
  },
  hide() { this.el.classList.add('hidden'); },
  multPulse() { const b = $('mult-box'); b.classList.add('pulse'); clearTimeout(this._pt); this._pt = setTimeout(() => b.classList.remove('pulse'), 160); },
  toast(text) {
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = text;
    $('toasts').appendChild(t); setTimeout(() => t.remove(), 2300);
  },
  update(g, myMass) {
    const now = performance.now();
    // Extraction bar every frame (smooth), text at 10 Hz.
    const ext = $('hud-ext');
    if (g.me.ext > 0) { ext.classList.remove('hidden'); $('hud-ext-fill').style.width = (g.me.ext * 100).toFixed(1) + '%'; }
    else ext.classList.add('hidden');
    if (now - this.lastText < 100) return;
    this.lastText = now;
    $('hud-mass').textContent = fmt(g.me.mass);
    const t = g.me.t; $('hud-time').textContent = `${(t / 60) | 0}:${String(t % 60).padStart(2, '0')}`;
    $('hud-alive').textContent = g.me.alive;
    $('hud-mult').textContent = g.me.mult.toFixed(1) + '×';
    $('hud-pot').textContent = fmt(g.potential());
    $('hud-mult-fill').style.width = Math.min(100, g.me.mult / g.me.cap * 100) + '%';
    $('mult-box').classList.toggle('hot', g.me.mult >= 2);
    const prot = $('hud-prot');
    if (g.me.prot > 0) { prot.classList.remove('hidden'); $('hud-prot-t').textContent = Math.ceil(g.me.prot); } else prot.classList.add('hidden');
    if (g.leaderboard) {
      let h = '';
      g.leaderboard.forEach((r, i) => { h += `<div class="${r[0] === g.myId ? 'me' : ''}"><span>${i + 1}. ${esc(r[1])}</span><b>${fmt(r[2])}</b></div>`; });
      $('hud-lb').innerHTML = h;
    }
  },
};
function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------
const app = {
  tr: null, game: null, renderer: null, input: null,
  account: null, name: '', risk: 10, offline: false, serverConfig: null,
  settings: ClientStore.getJSON('settings', { master: 80, sfx: 90, ambience: 35, quality: 'high' }),
  seenHowto: ClientStore.get('howto', '') === '1',
  state: 'connecting', lastFrame: 0, lastRisk: null,
};

function saveSettings() { ClientStore.setJSON('settings', app.settings); }
function applySettings() {
  audio.setVolumes({ master: app.settings.master / 100, sfx: app.settings.sfx / 100, ambience: app.settings.ambience / 100 });
  app.renderer.setQuality(app.settings.quality);
  $('quality-btn').textContent = app.settings.quality.toUpperCase();
  for (const [id, key] of [['vol-master', 'master'], ['vol-sfx', 'sfx'], ['vol-amb', 'ambience']]) { $(id).value = app.settings[key]; $(id + '-v').textContent = app.settings[key]; }
}

function show(id) { $(id).classList.remove('hidden'); }
function hide(id) { $(id).classList.add('hidden'); }

// ---- connection -----------------------------------------------------------
async function connect() {
  show('connecting'); $('connecting-msg').textContent = 'connecting…';
  const url = resolveServerUrl();
  let tr = null;
  try {
    tr = new WsTransport(url);
    await tr.connect(2500);
    app.offline = false;
  } catch (_) {
    tr = new LocalTransport();
    await tr.connect();
    app.offline = true;
  }
  app.tr = tr;
  $('offline-chip').classList.toggle('hidden', !app.offline);
  tr.on('message', onMessage);
  tr.on('close', onClose);
  tr.send({ t: 'hello', token: ClientStore.token(), name: app.name });
}

let reconnectTimer = null;
function onClose() {
  if (app.offline || app.state === 'kicked') return;
  hud.toast('Connection lost — reconnecting…');
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(async () => {
    try {
      const tr = new WsTransport(resolveServerUrl());
      await tr.connect(4000);
      app.tr = tr; app.game.tr = tr;
      tr.on('message', onMessage); tr.on('close', onClose);
      tr.send({ t: 'hello', token: ClientStore.token(), name: app.name });
    } catch (_) { onClose(); }
  }, 1500);
}

function onMessage(m) {
  switch (m.t) {
    case 'welcome':
      app.account = m.account; app.name = m.name; app.serverConfig = m.config;
      $('name').value = app.name;
      hide('connecting');
      if (m.allowance) setTimeout(() => hud.toast(`Daily allowance +${m.allowance} banked mass`), 400);
      if (app.state === 'connecting') { app.state = 'menu'; showMenu(); if (!app.seenHowto) openOverlay('howto'); }
      else if (app.state === 'menu') showMenu();
      break;
    case 'account': app.account = m.account; if (app.state === 'menu') showMenu(); break;
    case 'name': app.name = m.name; $('name').value = m.name; break;
    case 'joined':
      app.state = 'round';
      hide('menu'); hide('result'); hide('pause');
      app.game.streak = app.account ? app.account.streak : 0;
      app.game.onJoined(m);
      ads.gameplayStart();
      break;
    case 'snap': if (app.state === 'round') app.game.onSnap(m); break;
    case 'result': app.account = m.account; app.game.onResult(m); break;
    case 'pong': app.game.onPong(m); break;
    case 'kicked': app.state = 'kicked'; $('connecting-msg').textContent = 'This session was opened somewhere else. Reload to play here.'; show('connecting'); break;
    case 'err':
      if (m.code === 'inround') return;
      hud.toast(m.msg || 'Error');
      if (app.state === 'joining') { app.state = 'menu'; showMenu(); }
      break;
  }
}

// ---- menu -----------------------------------------------------------------
function showMenu() {
  show('menu'); hide('result'); hud.hide();
  const a = app.account;
  if (!a) return;
  $('menu-bank').textContent = fmt(a.bank);
  const st = $('menu-streak'); st.innerHTML = '';
  for (let i = 0; i < C.STREAK_MAX; i++) { const s = document.createElement('i'); if (i < a.streak) s.className = 'on'; st.appendChild(s); }
  $('menu-streak-note').textContent = a.streak > 0 ? `+${a.streak * 10}% payout · cap ${(C.MULT_CAP + a.streak * C.STREAK_CAP_BONUS).toFixed(1)}×` : '+10% payout per level';
  renderRisk();
}
function renderRisk() {
  const a = app.account; const grid = $('risk-grid'); grid.innerHTML = '';
  for (const pct of C.RISK_TIERS) {
    const tier = TIER_FOR_RISK(pct);
    const b = document.createElement('button');
    b.className = 'risk' + (tier === 'high' ? ' high' : '') + (pct === app.risk ? ' sel' : '');
    const amt = stakeFor(a.bank, pct);
    const clamped = amt !== Math.floor(a.bank * pct / 100);
    b.innerHTML = `<div class="pct">${pct}%</div><div class="amt">${fmt(amt)} mass${clamped ? ' <i>min</i>' : ''}</div>`;
    b.title = clamped ? `Minimum stake is ${C.MIN_STAKE}` : `${pct}% of your Bank`;
    b.onclick = () => { app.risk = pct; audio.ensure(); audio.ui(); renderRisk(); };
    grid.appendChild(b);
  }
  const tier = TIER_FOR_RISK(app.risk);
  const L = C.LOBBIES[tier];
  const stake = stakeFor(a.bank, app.risk);
  const after = Math.max(C.BANK_FLOOR, a.bank - stake);
  const floorHit = a.bank - stake < C.BANK_FLOOR;
  $('lobby-note').innerHTML = (tier === 'high'
    ? `<b>HIGH ROLLER</b> lobby · ${L.maxPlayers} max · fewer pellets · multiplier climbs ${L.multRate}× faster`
    : `<b>CASUAL</b> lobby · up to ${L.maxPlayers} · normal pellets`)
    + `<br>Bank after entering: <b>${fmt(after)}</b>${floorHit ? ` · mercy floor — Bank never drops below ${C.BANK_FLOOR}` : ''}`;
  $('btn-play').classList.toggle('high', tier === 'high');
  $('btn-play').textContent = `PLAY — RISK ${fmt(stake)} MASS`;
}

function play() {
  if (app.state !== 'menu') return;
  audio.ensure();
  audio.ui();
  const n = cleanName($('name').value);
  if (n !== app.name) { app.name = n; ClientStore.set('name', n); app.tr.send({ t: 'name', name: n }); }
  app.state = 'joining';
  app.lastRisk = app.risk;
  app.tr.send({ t: 'join', risk: app.risk });
}

// ---- overlays -------------------------------------------------------------
function openOverlay(id) {
  audio.ensure();
  if (id === 'skins') renderSkins();
  if (id === 'stats') renderStats();
  show(id);
}
function closeOverlays() { for (const id of ['settings', 'howto', 'skins', 'stats']) hide(id); }
document.querySelectorAll('[data-open]').forEach((b) => b.addEventListener('click', () => { audio.ui(); openOverlay(b.dataset.open); }));
document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => { audio.ui(); closeOverlays(); }));
$('howto-done').addEventListener('click', () => { ClientStore.set('howto', '1'); app.seenHowto = true; });
$('howto-btn').addEventListener('click', () => { hide('settings'); openOverlay('howto'); });

function renderSkins() {
  const grid = $('skin-grid'); grid.innerHTML = '';
  const a = app.account;
  SKINS.forEach((s, i) => {
    const b = document.createElement('button');
    const unlocked = i < a.skinsUnlocked;
    b.className = 'skin' + (i === a.skin ? ' sel' : '') + (unlocked ? '' : ' locked');
    const cv = document.createElement('canvas'); cv.width = cv.height = 96;
    const sp = skinSprite(i); cv.getContext('2d').drawImage(sp.canvas, 0, 0, 96, 96);
    b.appendChild(cv);
    const label = document.createElement('span'); label.textContent = s.name; b.appendChild(label);
    if (!unlocked) { const l = document.createElement('span'); l.className = 'lock'; l.textContent = `Bank ${fmt(C.SKIN_MILESTONES[i - 1])}`; b.appendChild(l); }
    b.onclick = () => { if (!unlocked) return; audio.ui(); app.tr.send({ t: 'skin', skin: i }); a.skin = i; renderSkins(); };
    grid.appendChild(b);
  });
}
function renderStats() {
  const s = app.account.stats;
  const rows = [['Biggest extraction', fmt(s.biggestExtraction)], ['Best multiplier', s.bestMult.toFixed(1) + '×'], ['Longest streak', s.longestStreak], ['Players eaten', s.playersEaten], ['Rounds', s.rounds], ['Extractions', s.extractions], ['Best Bank', fmt(app.account.bestBank)], ['Deaths', s.deaths]];
  $('stats-grid').innerHTML = rows.map(([k, v]) => `<div><div class="k">${k}</div><div class="v">${v}</div></div>`).join('');
}

// ---- settings wiring ------------------------------------------------------
for (const [id, key] of [['vol-master', 'master'], ['vol-sfx', 'sfx'], ['vol-amb', 'ambience']]) {
  $(id).addEventListener('input', (e) => { app.settings[key] = +e.target.value; $(id + '-v').textContent = e.target.value; audio.ensure(); audio.setVolumes({ [key]: app.settings[key] / 100 }); saveSettings(); });
  $(id).addEventListener('change', () => audio.ui());
}
$('quality-btn').addEventListener('click', () => { app.settings.quality = app.settings.quality === 'high' ? 'low' : 'high'; applySettings(); saveSettings(); audio.ui(); });

// ---- pause / leave --------------------------------------------------------
function togglePause() {
  if (app.state !== 'round') { closeOverlays(); return; }
  if (!$('settings').classList.contains('hidden')) { hide('settings'); return; }
  $('pause').classList.toggle('hidden');
  audio.ui();
}
$('btn-resume').addEventListener('click', () => { hide('pause'); audio.ui(); });
$('btn-leave').addEventListener('click', () => { hide('pause'); app.tr.send({ t: 'leave' }); });

// ---- result ---------------------------------------------------------------
function showResult(m) {
  const r = m.result, a = m.account;
  app.state = 'result';
  hud.hide(); hide('pause'); closeOverlays();
  const p = $('result-panel');
  p.classList.toggle('dead', r.kind !== 'extract');
  p.classList.toggle('big', r.kind === 'extract' && r.mult >= 3);
  const g = $('res-grid');
  if (r.kind === 'extract') {
    $('res-kicker').textContent = r.mult >= 3 ? 'BIG EXTRACTION' : (r.mult >= 1 ? 'EXTRACTED' : 'CUT YOUR LOSSES');
    $('res-big').textContent = (r.profit >= 0 ? '+' : '') + fmt(r.profit);
    $('res-line').textContent = `${fmt(r.stake)} risked × ${r.mult.toFixed(1)}${r.streakBefore ? ` × streak +${r.streakBefore * 10}%` : ''} = ${fmt(r.payout)} banked`;
  } else {
    $('res-kicker').textContent = r.reason === 'afk' ? 'REMOVED — IDLE' : r.reason === 'left' ? 'LEFT THE ARENA' : 'EATEN';
    $('res-big').textContent = '−' + fmt(r.lost);
    $('res-line').textContent = r.byName ? `${r.byName} ate you at ${r.mult.toFixed(1)}×. Stake lost.` : 'Stake lost.';
  }
  g.innerHTML = [['MULT', r.mult.toFixed(1) + '×'], ['PEAK', fmt(r.peakMass)], ['EATEN', r.kills], ['TIME', `${(r.survived / 60) | 0}:${String(r.survived % 60).padStart(2, '0')}`]]
    .map(([k, v]) => `<div><div class="k">${k}</div><div class="v">${v}</div></div>`).join('');
  $('res-bank').textContent = fmt(a.bank);
  const sc = $('res-streak');
  if (r.kind === 'extract' && r.streak > 0) { sc.textContent = `STREAK ${r.streak}`; sc.className = 'chip gold'; }
  else if (r.kind !== 'extract' && r.streakBefore) { sc.textContent = 'STREAK LOST'; sc.className = 'chip'; }
  else if (r.kind !== 'extract' && a.streak === 0 && (app.account?.streak || 0) === 0) { sc.textContent = ''; sc.className = 'chip hidden'; }
  else { sc.textContent = ''; sc.className = 'chip hidden'; }
  const adBtn = $('btn-ad-reenter');
  adBtn.classList.toggle('hidden', !(C.ADS_ENABLED && ads.available && r.kind !== 'extract'));
  $('btn-again').textContent = `PLAY AGAIN — RISK ${fmt(stakeFor(a.bank, app.lastRisk || app.risk))} MASS`;
  setTimeout(() => show('result'), r.kind === 'extract' ? 350 : 700);
}
$('btn-again').addEventListener('click', () => { hide('result'); app.state = 'menu'; app.risk = app.lastRisk || app.risk; play(); });
$('btn-menu').addEventListener('click', () => { hide('result'); app.state = 'menu'; audio.ui(); showMenu(); });
$('btn-ad-reenter').addEventListener('click', async () => { const ok = await ads.showRewarded('reenter'); if (ok) app.tr.send({ t: 'ad', kind: 'reenter' }); });

// ---- boot -----------------------------------------------------------------
function boot() {
  app.name = ClientStore.get('name', '') || '';
  app.renderer = new Renderer($('game'), $('minimap'));
  app.input = new Input($('game'), {
    split: () => app.game.split(), eject: () => app.game.eject(), pause: togglePause,
  });
  app.game = new GameClient({ transport: null, renderer: app.renderer, input: app.input, audio, hud, onEnd: showResult });
  Object.defineProperty(app.game, 'tr', { get: () => app.tr, set() {} });
  applySettings();
  $('btn-play').addEventListener('click', play);
  $('name').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.target.blur(); play(); } });
  $('name').addEventListener('change', () => { app.name = cleanName($('name').value); ClientStore.set('name', app.name); });
  window.addEventListener('touchstart', () => document.body.classList.add('touch'), { once: true, passive: true });
  window.addEventListener('pointerdown', () => audio.ensure(), { once: true });
  ads.init().catch(() => {});
  connect();
  requestAnimationFrame(loop);
}

function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.1, (now - (app.lastFrame || now)) / 1000);
  app.lastFrame = now;
  if (app.state === 'round' || app.state === 'result') {
    app.game.frame(now, dt);
    if (app.game.snaps.length) { app.renderer.draw(app.game.scene); if (app.state === 'round') app.renderer.drawMinimap(app.game.scene); }
    else app.renderer.clearMenuBackdrop(now);
  } else {
    app.renderer.clearMenuBackdrop(now);
  }
}

boot();
window.CELL = app; // handle for automated tests / console inspection
