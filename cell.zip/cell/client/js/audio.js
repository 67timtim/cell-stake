// Procedural WebAudio SFX — no asset files. Everything routes through
// master -> (sfx | ambience) gain nodes controlled by the settings sliders.
export class AudioSys {
  constructor() {
    this.ctx = null; this.master = null; this.sfx = null; this.amb = null;
    this.vol = { master: 0.8, sfx: 0.9, ambience: 0.35 };
    this.lastPellet = 0; this.hum = null; this.ambNodes = null;
    this.muted = false;
  }
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return true; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    this.ctx = new AC();
    this.master = this.ctx.createGain(); this.master.connect(this.ctx.destination);
    this.sfx = this.ctx.createGain(); this.sfx.connect(this.master);
    this.amb = this.ctx.createGain(); this.amb.connect(this.master);
    this.applyVolumes();
    return true;
  }
  setVolumes(v) { Object.assign(this.vol, v); this.applyVolumes(); }
  applyVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = this.muted ? 0 : this.vol.master;
    this.sfx.gain.value = this.vol.sfx;
    this.amb.gain.value = this.vol.ambience;
  }
  now() { return this.ctx ? this.ctx.currentTime : 0; }

  // Generic short tone helper.
  tone({ f = 440, f2 = null, type = 'sine', dur = 0.15, gain = 0.3, attack = 0.005, dest = null, when = 0 }) {
    if (!this.ctx) return;
    const t = this.now() + when;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (f2 !== null) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest || this.sfx);
    o.start(t); o.stop(t + dur + 0.02);
  }
  noise({ dur = 0.2, gain = 0.2, hp = 800, when = 0 }) {
    if (!this.ctx) return;
    const t = this.now() + when;
    const n = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const src = this.ctx.createBufferSource(); src.buffer = buf;
    const f = this.ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp;
    const g = this.ctx.createGain(); g.gain.value = gain;
    src.connect(f); f.connect(g); g.connect(this.sfx);
    src.start(t);
  }

  // ---- game sounds ----
  pellet() {
    if (!this.ctx) return;
    const t = performance.now();
    if (t - this.lastPellet < 45) return;
    this.lastPellet = t;
    this.tone({ f: 900 + Math.random() * 400, f2: 1400, type: 'sine', dur: 0.06, gain: 0.08 });
  }
  eat(mass) {
    const f = Math.max(120, 700 - Math.sqrt(mass) * 12);
    this.tone({ f: f * 1.5, f2: f * 0.6, type: 'triangle', dur: 0.18, gain: 0.35 });
    this.noise({ dur: 0.08, gain: 0.08, hp: 2000 });
  }
  kill() {
    this.eat(600);
    this.tone({ f: 523, type: 'sine', dur: 0.25, gain: 0.25, when: 0.05 });
    this.tone({ f: 784, type: 'sine', dur: 0.35, gain: 0.25, when: 0.15 });
    this.tone({ f: 1046, type: 'sine', dur: 0.5, gain: 0.22, when: 0.25 });
  }
  hurt() {
    this.tone({ f: 160, f2: 60, type: 'sawtooth', dur: 0.3, gain: 0.35 });
    this.noise({ dur: 0.25, gain: 0.15, hp: 300 });
  }
  split() { this.noise({ dur: 0.18, gain: 0.18, hp: 1200 }); this.tone({ f: 300, f2: 700, type: 'sine', dur: 0.12, gain: 0.15 }); }
  eject() { this.tone({ f: 500, f2: 250, type: 'sine', dur: 0.08, gain: 0.12 }); }
  ui() { this.tone({ f: 660, type: 'sine', dur: 0.06, gain: 0.12 }); }
  multTick(mult) {
    // rising tick as multiplier grows
    const f = 600 + Math.min(4, mult) * 220;
    this.tone({ f, type: 'square', dur: 0.05, gain: 0.08 });
    this.tone({ f: f * 1.5, type: 'sine', dur: 0.12, gain: 0.12, when: 0.03 });
  }
  death() {
    this.tone({ f: 110, f2: 30, type: 'sawtooth', dur: 1.2, gain: 0.5 });
    this.tone({ f: 220, f2: 55, type: 'triangle', dur: 0.8, gain: 0.3, when: 0.05 });
    this.noise({ dur: 0.6, gain: 0.25, hp: 150 });
  }
  extractSuccess(mult) {
    const base = mult >= 3 ? 392 : 330;
    [0, 4, 7, 12, 16].forEach((semi, i) => this.tone({ f: base * Math.pow(2, semi / 12), type: 'sine', dur: 0.9, gain: 0.22, when: i * 0.07 }));
    if (mult >= 3) [24, 19, 28].forEach((semi, i) => this.tone({ f: base * Math.pow(2, semi / 12), type: 'triangle', dur: 1.4, gain: 0.15, when: 0.5 + i * 0.1 }));
  }
  channelBreak() { this.tone({ f: 400, f2: 120, type: 'square', dur: 0.2, gain: 0.15 }); }

  // Extraction channel hum: continuous, pitch rises with progress (0..1).
  setChannel(progress) {
    if (!this.ctx) return;
    if (progress <= 0) { if (this.hum) { this.hum.g.gain.setTargetAtTime(0, this.now(), 0.05); const h = this.hum; setTimeout(() => { try { h.o.stop(); h.o2.stop(); } catch (_) {} }, 200); this.hum = null; } return; }
    if (!this.hum) {
      const o = this.ctx.createOscillator(), o2 = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = 'sine'; o2.type = 'triangle';
      g.gain.value = 0; o.connect(g); o2.connect(g); g.connect(this.sfx); o.start(); o2.start();
      this.hum = { o, o2, g };
      g.gain.setTargetAtTime(0.18, this.now(), 0.05);
    }
    const f = 220 * Math.pow(2, progress * 1.0);
    this.hum.o.frequency.setTargetAtTime(f, this.now(), 0.03);
    this.hum.o2.frequency.setTargetAtTime(f * 1.5 + progress * 40, this.now(), 0.03);
  }

  // Soft ambient pad while in the arena.
  ambience(on) {
    if (!this.ctx) return;
    if (on && !this.ambNodes) {
      const g = this.ctx.createGain(); g.gain.value = 0; g.connect(this.amb);
      const oscs = [55, 82.4, 110, 164.8].map((f, i) => {
        const o = this.ctx.createOscillator(); o.type = i % 2 ? 'triangle' : 'sine'; o.frequency.value = f; o.detune.value = (i - 1.5) * 4;
        const lg = this.ctx.createGain(); lg.gain.value = 0.25;
        const lfo = this.ctx.createOscillator(); lfo.frequency.value = 0.05 + i * 0.03; const lfg = this.ctx.createGain(); lfg.gain.value = 0.12;
        lfo.connect(lfg); lfg.connect(lg.gain); lfo.start();
        o.connect(lg); lg.connect(g); o.start();
        return { o, lfo };
      });
      const f = this.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500;
      g.disconnect(); g.connect(f); f.connect(this.amb);
      g.gain.setTargetAtTime(0.5, this.now(), 1.5);
      this.ambNodes = { g, oscs };
    } else if (!on && this.ambNodes) {
      const a = this.ambNodes; this.ambNodes = null;
      a.g.gain.setTargetAtTime(0, this.now(), 0.4);
      setTimeout(() => { for (const { o, lfo } of a.oscs) { try { o.stop(); lfo.stop(); } catch (_) {} } }, 2000);
    }
  }
}
export const audio = new AudioSys();
