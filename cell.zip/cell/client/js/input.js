// Desktop: mouse steers, Space = split, W = eject, Esc = pause.
// Mobile: left-half virtual joystick, right-side Split/Eject buttons.
export class Input {
  constructor(canvas, hooks) {
    this.canvas = canvas;
    this.hooks = hooks; // { split(), eject(), pause() }
    this.ptr = { x: 0, y: 0, has: false };
    this.joy = { active: false, id: -1, ox: 0, oy: 0, dx: 0, dy: 0 };
    this.isTouch = false;
    this.enabled = false;
    this.bind();
  }
  bind() {
    const c = this.canvas;
    c.addEventListener('mousemove', (e) => { if (this.isTouch) return; this.ptr.x = e.clientX; this.ptr.y = e.clientY; this.ptr.has = true; });
    c.addEventListener('mousedown', (e) => { if (this.isTouch) return; this.ptr.x = e.clientX; this.ptr.y = e.clientY; this.ptr.has = true; });
    window.addEventListener('keydown', (e) => {
      if (!this.enabled) { if (e.code === 'Escape') this.hooks.pause(); return; }
      if (e.repeat) return;
      if (e.code === 'Space') { e.preventDefault(); this.hooks.split(); }
      else if (e.code === 'KeyW') { e.preventDefault(); this.hooks.eject(); }
      else if (e.code === 'Escape') this.hooks.pause();
    });
    // Touch: joystick on the left half of the canvas.
    const onStart = (e) => {
      this.isTouch = true;
      for (const t of e.changedTouches) {
        if (!this.joy.active && t.clientX < window.innerWidth * 0.55) {
          this.joy.active = true; this.joy.id = t.identifier; this.joy.ox = t.clientX; this.joy.oy = t.clientY; this.joy.dx = 0; this.joy.dy = 0;
        }
      }
      if (this.enabled) e.preventDefault();
    };
    const onMove = (e) => {
      for (const t of e.changedTouches) {
        if (this.joy.active && t.identifier === this.joy.id) {
          let dx = t.clientX - this.joy.ox, dy = t.clientY - this.joy.oy;
          const d = Math.hypot(dx, dy), max = 70;
          if (d > max) { dx = dx / d * max; dy = dy / d * max; }
          this.joy.dx = dx; this.joy.dy = dy;
        }
      }
      if (this.enabled) e.preventDefault();
    };
    const onEnd = (e) => {
      for (const t of e.changedTouches) if (this.joy.active && t.identifier === this.joy.id) { this.joy.active = false; }
      if (this.enabled) e.preventDefault();
    };
    c.addEventListener('touchstart', onStart, { passive: false });
    c.addEventListener('touchmove', onMove, { passive: false });
    c.addEventListener('touchend', onEnd, { passive: false });
    c.addEventListener('touchcancel', onEnd, { passive: false });
    // Buttons (mobile)
    const bind = (id, fn) => {
      const el = document.getElementById(id);
      if (!el) return;
      const h = (e) => { e.preventDefault(); this.isTouch = true; fn(); el.classList.add('down'); setTimeout(() => el.classList.remove('down'), 120); };
      el.addEventListener('touchstart', h, { passive: false });
      el.addEventListener('mousedown', (e) => { e.preventDefault(); fn(); });
    };
    bind('btn-split', () => this.hooks.split());
    bind('btn-eject', () => this.hooks.eject());
    bind('btn-pause', () => this.hooks.pause());
    // Block context menu / gestures on canvas
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('gesturestart', (e) => e.preventDefault());
  }
  // Direction of desired movement in screen space; returns null when idle.
  // Desktop returns the pointer position (absolute), touch returns a vector.
  desired(w, h) {
    if (this.joy.active) {
      const d = Math.hypot(this.joy.dx, this.joy.dy);
      if (d < 4) return { mode: 'stop' };
      return { mode: 'vec', dx: this.joy.dx / 70, dy: this.joy.dy / 70 };
    }
    if (this.isTouch) return { mode: 'stop' };
    if (!this.ptr.has) return { mode: 'stop' };
    return { mode: 'point', x: this.ptr.x, y: this.ptr.y };
  }
}
