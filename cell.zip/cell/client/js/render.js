// Canvas 2D renderer. One draw loop, spatial culling by camera box, no
// per-frame allocations in the hot paths (arrays reused, sprites cached).
import { CONFIG as C } from '../shared/config.js';
import { SKINS, PELLET_PALETTE, skinSprite, hexA } from './skins.js';

const TAU = Math.PI * 2;
const GOLD = '#f5c542';

export class Renderer {
  constructor(canvas, minimap) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.mini = minimap;
    this.mctx = minimap.getContext('2d');
    this.W = 1; this.H = 1; this.dpr = 1;
    this.quality = 'high';
    this.pelletBuckets = PELLET_PALETTE.map(() => []);
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }
  setQuality(q) { this.quality = q; this.resize(); }
  resize() {
    const maxDpr = this.quality === 'low' ? 1 : 2;
    this.dpr = Math.min(maxDpr, window.devicePixelRatio || 1);
    this.W = window.innerWidth; this.H = window.innerHeight;
    this.canvas.width = Math.round(this.W * this.dpr);
    this.canvas.height = Math.round(this.H * this.dpr);
    this.canvas.style.width = this.W + 'px'; this.canvas.style.height = this.H + 'px';
    const ms = Math.min(150, Math.max(90, Math.round(Math.min(this.W, this.H) * 0.22)));
    this.mini.width = ms * this.dpr; this.mini.height = ms * this.dpr; this.mini.style.width = ms + 'px'; this.mini.style.height = ms + 'px';
  }

  clearMenuBackdrop(t) {
    // Idle background for menus: slow drifting grid.
    const ctx = this.ctx, W = this.W, H = this.H;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = '#0e1116'; ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1;
    const step = 60, off = (t * 0.01) % step;
    ctx.beginPath();
    for (let x = -off; x < W; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    for (let y = -off; y < H; y += step) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    ctx.stroke();
    const g = ctx.createRadialGradient(W / 2, H * 0.4, 0, W / 2, H * 0.4, Math.max(W, H) * 0.7);
    g.addColorStop(0, 'rgba(94,230,214,0.10)'); g.addColorStop(1, 'rgba(14,17,22,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }

  draw(s) {
    const ctx = this.ctx, W = this.W, H = this.H;
    const cam = s.cam;
    const z = cam.zoom;
    const shakeX = s.shake > 0.01 ? (Math.random() - 0.5) * s.shake : 0;
    const shakeY = s.shake > 0.01 ? (Math.random() - 0.5) * s.shake : 0;
    const ox = W / 2 - cam.x * z + shakeX, oy = H / 2 - cam.y * z + shakeY;
    const x0 = (0 - ox) / z, y0 = (0 - oy) / z, x1 = (W - ox) / z, y1 = (H - oy) / z; // world box

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = '#0e1116'; ctx.fillRect(0, 0, W, H);

    // ---- grid ----
    ctx.setTransform(this.dpr * z, 0, 0, this.dpr * z, this.dpr * ox, this.dpr * oy);
    const step = C.GRID_STEP;
    if (step * z >= 8) {
      ctx.strokeStyle = 'rgba(255,255,255,0.045)'; ctx.lineWidth = 1 / z;
      ctx.beginPath();
      const gx0 = Math.max(0, Math.floor(x0 / step) * step), gx1 = Math.min(C.MAP_SIZE, x1);
      const gy0 = Math.max(0, Math.floor(y0 / step) * step), gy1 = Math.min(C.MAP_SIZE, y1);
      for (let x = gx0; x <= gx1; x += step) { ctx.moveTo(x, Math.max(0, y0)); ctx.lineTo(x, Math.min(C.MAP_SIZE, y1)); }
      for (let y = gy0; y <= gy1; y += step) { ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(Math.min(C.MAP_SIZE, x1), y); }
      ctx.stroke();
    }
    // Walls
    ctx.strokeStyle = 'rgba(255,90,90,0.55)'; ctx.lineWidth = 6 / z;
    ctx.strokeRect(0, 0, C.MAP_SIZE, C.MAP_SIZE);
    // Outside-map shading
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    if (x0 < 0) ctx.fillRect(x0, y0, -x0, y1 - y0);
    if (x1 > C.MAP_SIZE) ctx.fillRect(C.MAP_SIZE, y0, x1 - C.MAP_SIZE, y1 - y0);
    if (y0 < 0) ctx.fillRect(x0, y0, x1 - x0, -y0);
    if (y1 > C.MAP_SIZE) ctx.fillRect(x0, C.MAP_SIZE, x1 - x0, y1 - C.MAP_SIZE);

    // ---- extraction rings ----
    const t = s.time;
    for (const r of s.rings) {
      if (r.x + r.r * 1.6 < x0 || r.x - r.r * 1.6 > x1 || r.y + r.r * 1.6 < y0 || r.y - r.r * 1.6 > y1) continue;
      const pulse = 0.5 + 0.5 * Math.sin(t * 2 + r.x);
      const active = r.channelers > 0;
      ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, TAU);
      ctx.fillStyle = active ? `rgba(245,197,66,${0.10 + pulse * 0.08})` : `rgba(245,197,66,${0.05 + pulse * 0.03})`;
      ctx.fill();
      ctx.lineWidth = Math.max((active ? 4 : 2.5) / z, r.r * (active ? 0.035 : 0.025));
      ctx.strokeStyle = active ? GOLD : hexA(GOLD, 0.65 + pulse * 0.25);
      ctx.stroke();
      // inner dashed ring
      ctx.setLineDash([24, 18]); ctx.lineDashOffset = -t * 40;
      ctx.lineWidth = Math.max(1 / z, r.r * 0.01); ctx.strokeStyle = hexA(GOLD, 0.5);
      ctx.beginPath(); ctx.arc(r.x, r.y, r.r * 0.72, 0, TAU); ctx.stroke();
      ctx.setLineDash([]);
      // Broadcast channel progress arc: everyone nearby can see someone extracting.
      if (active && r.best > 0) {
        ctx.beginPath(); ctx.arc(r.x, r.y, r.r * 1.07, -Math.PI / 2, -Math.PI / 2 + TAU * r.best);
        ctx.lineWidth = Math.max(3 / z, r.r * 0.05); ctx.strokeStyle = '#fff1a8'; ctx.stroke();
      }
      // label
      const fs = Math.min(r.r * 0.32, 26 / z);
      if (fs * z > 8) {
        ctx.font = `800 ${fs}px "Archivo", "Inter Tight", "Helvetica Neue", Arial, sans-serif`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = hexA(GOLD, 0.85);
        ctx.fillText(active ? 'EXTRACTING' : 'EXTRACT', r.x, r.y - r.r * 1.12 - fs * 0.7);
      }
    }

    // ---- pellets (batched by colour) ----
    const pr = Math.max(8, 2.5 / Math.max(z, 0.05));
    for (const b of this.pelletBuckets) b.length = 0;
    for (const p of s.pellets.values()) {
      if (p.x < x0 - pr || p.x > x1 + pr || p.y < y0 - pr || p.y > y1 + pr) continue;
      this.pelletBuckets[p.c].push(p);
    }
    for (let i = 0; i < PELLET_PALETTE.length; i++) {
      const b = this.pelletBuckets[i];
      if (!b.length) continue;
      ctx.fillStyle = PELLET_PALETTE[i];
      ctx.beginPath();
      for (let k = 0; k < b.length; k++) { const p = b[k]; ctx.moveTo(p.x + pr, p.y); ctx.arc(p.x, p.y, pr, 0, TAU); }
      ctx.fill();
    }

    // ---- ejected blobs ----
    for (const e of s.ejected) {
      if (e.x < x0 - 30 || e.x > x1 + 30 || e.y < y0 - 30 || e.y > y1 + 30) continue;
      const sk = SKINS[e.c % SKINS.length];
      ctx.fillStyle = sk.c1;
      ctx.beginPath(); ctx.arc(e.x, e.y, Math.sqrt(e.mass) * C.RADIUS_SCALE, 0, TAU); ctx.fill();
    }

    // ---- cells (small first, big on top) ----
    for (const c of s.cells) {
      if (c.x + c.r < x0 || c.x - c.r > x1 || c.y + c.r < y0 || c.y - c.r > y1) continue;
      const sp = skinSprite(c.skin);
      const d = c.r * 2 * sp.scale;
      ctx.globalAlpha = c.prot ? 0.45 + 0.15 * Math.sin(t * 10) : 1;
      ctx.drawImage(sp.canvas, c.x - d / 2, c.y - d / 2, d, d);
      if (c.channeling) {
        ctx.strokeStyle = GOLD; ctx.lineWidth = 4 / z;
        ctx.beginPath(); ctx.arc(c.x, c.y, c.r + 6 / z, 0, TAU); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    // Names + mass, only when readable.
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const c of s.cells) {
      if (c.x + c.r < x0 || c.x - c.r > x1 || c.y + c.r < y0 || c.y - c.r > y1) continue;
      const px = c.r * z;
      if (px < 14) continue;
      const fs = Math.max(11 / z, Math.min(c.r * 0.42, 40 / z));
      ctx.font = `800 ${fs}px "Archivo", "Inter Tight", "Helvetica Neue", Arial, sans-serif`;
      ctx.lineWidth = fs * 0.14; ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.fillStyle = '#fff';
      ctx.strokeText(c.name, c.x, c.y - (px > 30 ? fs * 0.35 : 0)); ctx.fillText(c.name, c.x, c.y - (px > 30 ? fs * 0.35 : 0));
      if (px > 30) {
        const fs2 = fs * 0.7;
        ctx.font = `600 ${fs2}px "Archivo", "Inter Tight", "Helvetica Neue", Arial, sans-serif`;
        ctx.strokeText(Math.round(c.mass), c.x, c.y + fs * 0.55); ctx.fillText(Math.round(c.mass), c.x, c.y + fs * 0.55);
      }
    }

    // ---- particles ----
    for (const p of s.particles) {
      if (p.life <= 0) continue;
      ctx.globalAlpha = Math.min(1, p.life * 2);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.4 + p.life * 0.6), 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;

    // ---- floating texts ----
    for (const f of s.floaters) {
      if (f.life <= 0) continue;
      const fs = f.size / z;
      ctx.font = `900 ${fs}px "Archivo", "Inter Tight", "Helvetica Neue", Arial, sans-serif`;
      ctx.globalAlpha = Math.min(1, f.life);
      ctx.lineWidth = fs * 0.12; ctx.strokeStyle = 'rgba(0,0,0,0.7)'; ctx.fillStyle = f.color;
      ctx.strokeText(f.text, f.x, f.y); ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;

    // ---- joystick ----
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    if (s.joy && s.joy.active) {
      ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(s.joy.ox, s.joy.oy, 70, 0, TAU); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.arc(s.joy.ox + s.joy.dx, s.joy.oy + s.joy.dy, 26, 0, TAU); ctx.fill();
    }
    // ---- screen flash / vignette ----
    if (s.flash > 0.01) {
      ctx.fillStyle = `rgba(${s.flashColor},${s.flash})`; ctx.fillRect(0, 0, W, H);
    }
    if (s.vignette > 0.01) {
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(${s.vignetteColor},${s.vignette})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
  }

  drawMinimap(s) {
    const m = this.mctx, S = this.mini.width;
    m.setTransform(1, 0, 0, 1, 0, 0);
    m.clearRect(0, 0, S, S);
    m.fillStyle = 'rgba(14,17,22,0.75)'; m.fillRect(0, 0, S, S);
    m.strokeStyle = 'rgba(255,255,255,0.15)'; m.lineWidth = 1; m.strokeRect(0.5, 0.5, S - 1, S - 1);
    const k = S / C.MAP_SIZE;
    for (const r of s.rings) {
      m.strokeStyle = r.channelers > 0 ? '#fff1a8' : GOLD; m.lineWidth = 2;
      m.beginPath(); m.arc(r.x * k, r.y * k, Math.max(4, r.r * k), 0, TAU); m.stroke();
    }
    // Viewport box
    const vw = this.W / s.cam.zoom * k, vh = this.H / s.cam.zoom * k;
    m.strokeStyle = 'rgba(255,255,255,0.35)'; m.lineWidth = 1;
    m.strokeRect(s.cam.x * k - vw / 2, s.cam.y * k - vh / 2, vw, vh);
    // Me
    if (s.me) {
      m.fillStyle = '#5ee6d6';
      m.beginPath(); m.arc(s.me.x * k, s.me.y * k, 3.5 * this.dpr, 0, TAU); m.fill();
    }
  }
}
