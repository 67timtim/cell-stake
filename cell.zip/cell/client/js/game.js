// In-round client: snapshot buffer, interpolation (~100 ms behind), light
// prediction for the local player's cells, input sending, juice.
import { CONFIG as C } from '../shared/config.js';
import { radiusOf, speedOf, viewWidth } from '../shared/sim.js';
import { SKINS, PELLET_PALETTE } from './skins.js';

const MAX_SNAPS = 12;
const P_COUNT = 320;

export class GameClient {
  constructor({ transport, renderer, input, audio, hud, onEnd }) {
    this.tr = transport; this.r = renderer; this.input = input; this.audio = audio; this.hud = hud; this.onEnd = onEnd;
    this.active = false;
    this.myId = -1; this.stake = 0; this.tier = 'casual';
    this.snaps = [];
    this.pellets = new Map();
    this.pendingPelletRemovals = [];
    this.players = new Map(); // id -> {name, skin, mult, prot, chan}
    this.clockOffset = null;   // performance.now() - serverTs (ms), min-filtered
    this.rtt = 80;
    this.seq = 0; this.lastInputSent = 0;
    this.pendingSplit = false; this.pendingEject = false;
    this.cam = { x: C.MAP_SIZE / 2, y: C.MAP_SIZE / 2, zoom: 0.5 };
    this.me = { mass: C.START_MASS, mult: 0, ext: 0, ring: -1, prot: 0, kills: 0, peak: C.START_MASS, alive: 0, cap: C.MULT_CAP, t: 0 };
    this.target = { x: 0, y: 0 };
    this.particles = Array.from({ length: P_COUNT }, () => ({ x: 0, y: 0, vx: 0, vy: 0, life: 0, size: 4, color: '#fff' }));
    this.pi = 0;
    this.floaters = [];
    this.scene = { cam: this.cam, pellets: this.pellets, ejected: [], cells: [], rings: [], particles: this.particles, floaters: this.floaters, shake: 0, flash: 0, flashColor: '255,255,255', vignette: 0, vignetteColor: '255,60,60', time: 0, joy: null, me: null };
    this.shake = 0; this.flash = 0; this.vignette = 0;
    this.lastMultShown = 0;
    this.leaderboard = [];
    this.myCells = new Map(); // id -> predicted {x,y}
    this.lastPingAt = 0;
    this.result = null;
    this.rings = C.RINGS.map(r => ({ x: r.x, y: r.y, r: C.RING_RADIUS, channelers: 0, best: 0 }));
    this.scene.rings = this.rings;
    this._cellPool = [];
    this._chanBefore = 0;
  }

  // ---- messages -------------------------------------------------------------
  onJoined(m) {
    this.active = true; this.myId = m.id; this.stake = m.stake; this.tier = m.tier;
    this.snaps.length = 0; this.pellets.clear(); this.players.clear(); this.myCells.clear();
    this.pendingPelletRemovals.length = 0; this.clockOffset = null; this.result = null;
    this.rings = m.rings.map(r => ({ x: r.x, y: r.y, r: r.r, channelers: 0, best: 0 }));
    this.scene.rings = this.rings;
    this.me = { mass: C.START_MASS, mult: 0, ext: 0, ring: -1, prot: C.SPAWN_PROTECT_SEC, kills: 0, peak: C.START_MASS, alive: 0, cap: C.MULT_CAP, t: 0 };
    this.lastMultShown = 0;
    this.shake = 0; this.flash = 0; this.vignette = 0; this.camSnap = true;
    for (const p of this.particles) p.life = 0;
    this.floaters.length = 0;
    this.input.enabled = true;
    this.audio.ambience(true);
    this.hud.roundStart(this);
  }

  onSnap(m) {
    const now = performance.now();
    const off = now - m.ts;
    // Clock offset: track the minimum (least-delayed) with slow drift upward.
    if (this.clockOffset === null) this.clockOffset = off;
    else if (off < this.clockOffset) this.clockOffset = off;
    else this.clockOffset += (off - this.clockOffset) * 0.02;

    // Cells -> map for interpolation
    const cells = new Map();
    for (let i = 0; i < m.c.length; i += 6) cells.set(m.c[i], { owner: m.c[i + 1], x: m.c[i + 2], y: m.c[i + 3], m: m.c[i + 4], merging: m.c[i + 5] });
    const ej = [];
    for (let i = 0; i < m.e.length; i += 5) ej.push({ id: m.e[i], x: m.e[i + 1], y: m.e[i + 2], mass: m.e[i + 3], c: m.e[i + 4] });
    for (let i = 0; i < m.pa.length; i += 4) this.pellets.set(m.pa[i], { x: m.pa[i + 1], y: m.pa[i + 2], c: m.pa[i + 3] });
    if (m.pr.length) this.pendingPelletRemovals.push({ ts: m.ts, ids: m.pr });
    for (const id in m.pl) {
      const a = m.pl[id];
      let p = this.players.get(+id);
      if (!p) { p = { name: a[0], skin: a[1], mult: a[2], prot: a[3], chan: a[4] }; this.players.set(+id, p); }
      else { p.name = a[0]; p.skin = a[1]; p.mult = a[2]; p.prot = a[3]; p.chan = a[4]; }
    }
    if (m.lb) this.leaderboard = m.lb;
    for (let i = 0; i < m.rg.length && i < this.rings.length; i++) { this.rings[i].channelers = m.rg[i][0]; this.rings[i].best = m.rg[i][1]; }
    const prevMe = this.me;
    this.me = { mass: m.me.m, mult: m.me.mult, ext: m.me.ext, ring: m.me.ring, prot: m.me.prot, kills: m.me.kills, peak: m.me.peak, alive: m.me.alive, cap: m.me.cap, t: m.me.t };
    if (this.me.mult > this.lastMultShown + 1e-6) { if (this.lastMultShown > 0 || this.me.mult > 0) this.audio.multTick(this.me.mult); this.lastMultShown = this.me.mult; this.hud.multPulse(); }
    if (this.me.ext > 0 || prevMe.ext > 0) this.audio.setChannel(this.me.ext);
    this.snaps.push({ ts: m.ts, cells, ej });
    if (this.snaps.length > MAX_SNAPS) this.snaps.shift();
    for (const ev of m.ev) this.onEvent(ev);
  }

  onEvent(ev) {
    switch (ev.t) {
      case 'pel': if (ev.p === this.myId) this.audio.pellet(); break;
      case 'eat': {
        const mine = ev.p === this.myId, victim = ev.v === this.myId;
        const col = SKINS[ev.c % SKINS.length].c1;
        this.burst(ev.x, ev.y, Math.min(60, 8 + Math.sqrt(ev.m) * 2), col, Math.min(900, 200 + Math.sqrt(ev.m) * 40));
        if (mine) { this.audio.eat(ev.m); this.floater(ev.x, ev.y, '+' + Math.round(ev.m * C.EAT_GAIN), 26, '#fff'); }
        else if (victim) { this.audio.hurt(); this.shake = Math.min(24, 8 + Math.sqrt(ev.m)); this.flash = 0.25; this.scene.flashColor = '255,60,60'; }
        break;
      }
      case 'death': {
        if (ev.p === this.myId) break; // result screen handles us
        const p = this.players.get(ev.p);
        if (ev.by === this.myId && p) { this.audio.kill(); this.floater(ev.x, ev.y, 'ATE ' + p.name.toUpperCase(), 34, '#f5c542'); this.hud.toast(`You ate ${p.name}  +0.5×`); this.shake = 6; }
        break;
      }
      case 'split': if (ev.p === this.myId) this.audio.split(); break;
      case 'eject': if (ev.p === this.myId) this.audio.eject(); break;
      case 'chanstart': if (ev.p === this.myId) this.hud.toast('Hold position…'); break;
      case 'chanbreak': if (ev.p === this.myId) { this.audio.channelBreak(); this.hud.toast('Extraction interrupted'); } break;
      case 'extract': {
        this.burst(ev.x, ev.y, 80, '#f5c542', 700);
        if (ev.p !== this.myId) { const p = this.players.get(ev.p); if (p) this.floater(ev.x, ev.y, p.name + ' extracted', 30, '#f5c542'); }
        break;
      }
    }
  }

  onResult(m) {
    this.result = m.result;
    this.active = false; this.input.enabled = false;
    this.audio.setChannel(0);
    this.audio.ambience(false);
    if (m.result.kind === 'extract') { this.audio.extractSuccess(m.result.mult); this.flash = 0.6; this.scene.flashColor = '245,197,66'; }
    else { this.audio.death(); this.shake = 30; this.flash = 0.7; this.scene.flashColor = '255,40,40'; this.vignette = 1; }
    this.onEnd(m);
  }

  // ---- input --------------------------------------------------------------
  split() { if (this.active) this.pendingSplit = true; }
  eject() { if (this.active) this.pendingEject = true; }

  sendInput(now) {
    if (!this.active) return;
    if (now - this.lastInputSent < 1000 / C.INPUT_RATE) return;
    this.lastInputSent = now;
    const msg = { t: 'in', q: ++this.seq, x: Math.round(this.target.x), y: Math.round(this.target.y) };
    if (this.pendingSplit) { msg.s = 1; this.pendingSplit = false; }
    if (this.pendingEject) { msg.e = 1; this.pendingEject = false; }
    this.tr.send(msg);
    if (now - this.lastPingAt > 2000) { this.lastPingAt = now; this.pingSent = now; this.tr.send({ t: 'ping', c: now }); }
  }
  onPong(m) { if (m.c) this.rtt = this.rtt * 0.7 + (performance.now() - m.c) * 0.3; }

  // ---- frame ---------------------------------------------------------------
  frame(now, dt) {
    const s = this.scene;
    // Interpolation time in server clock
    if (this.clockOffset === null || this.snaps.length === 0) return;
    const renderTs = now - this.clockOffset - C.INTERP_DELAY_MS;
    // Pellet removals (delayed to match interpolation)
    while (this.pendingPelletRemovals.length && this.pendingPelletRemovals[0].ts <= renderTs) {
      const r = this.pendingPelletRemovals.shift();
      for (const id of r.ids) this.pellets.delete(id);
    }
    // Bracketing snapshots
    let a = this.snaps[0], b = this.snaps[0];
    for (let i = 0; i < this.snaps.length; i++) {
      if (this.snaps[i].ts <= renderTs) a = this.snaps[i];
      if (this.snaps[i].ts >= renderTs) { b = this.snaps[i]; break; }
      b = this.snaps[i];
    }
    const alpha = b.ts > a.ts ? Math.max(0, Math.min(1, (renderTs - a.ts) / (b.ts - a.ts))) : 1;
    const latest = this.snaps[this.snaps.length - 1];

    // Build cell list
    const cells = s.cells; cells.length = 0;
    let poolI = 0;
    let myMass = 0, mcx = 0, mcy = 0;
    const lead = Math.min(0.25, (C.INTERP_DELAY_MS + this.rtt / 2) / 1000);
    for (const [id, cb] of b.cells) {
      const ca = a.cells.get(id) || cb;
      let x = ca.x + (cb.x - ca.x) * alpha, y = ca.y + (cb.y - ca.y) * alpha;
      const m = ca.m + (cb.m - ca.m) * alpha;
      const r = radiusOf(m);
      const p = this.players.get(cb.owner);
      const isMe = cb.owner === this.myId;
      if (isMe) {
        // Prediction: lead the interpolated position along the current input,
        // matching what the server will do with the inputs already in flight.
        const dx = this.target.x - x, dy = this.target.y - y;
        const d = Math.hypot(dx, dy);
        if (d > 1) { const f = Math.min(1, d / Math.max(20, r)); const sp = speedOf(m) * f * lead; const k = Math.min(1, sp / d); x += dx * k; y += dy * k; }
        // Smooth against small server corrections
        let pc = this.myCells.get(id);
        if (!pc) { pc = { x, y }; this.myCells.set(id, pc); }
        else { const err = Math.hypot(pc.x - x, pc.y - y); const k = err > 120 ? 1 : 1 - Math.pow(0.001, dt); pc.x += (x - pc.x) * k; pc.y += (y - pc.y) * k; }
        x = pc.x; y = pc.y;
        myMass += m; mcx += x * m; mcy += y * m;
      }
      const o = this._cellPool[poolI] || (this._cellPool[poolI] = {});
      poolI++;
      o.id = id; o.owner = cb.owner; o.x = x; o.y = y; o.r = r; o.mass = m; o.skin = p ? p.skin : 0; o.name = p ? p.name : '';
      o.isMe = isMe; o.prot = p ? !!p.prot : false; o.channeling = p ? !!p.chan : false; o.merging = !!cb.merging;
      cells.push(o);
    }
    for (const id of this.myCells.keys()) if (!b.cells.has(id)) this.myCells.delete(id);
    cells.sort((u, v) => u.mass - v.mass);
    // Ejected: use latest positions lerped from a->b by id
    const ej = s.ejected; ej.length = 0;
    for (const eb of b.ej) {
      let ea = null;
      for (const q of a.ej) if (q.id === eb.id) { ea = q; break; }
      if (ea) ej.push({ x: ea.x + (eb.x - ea.x) * alpha, y: ea.y + (eb.y - ea.y) * alpha, mass: eb.mass, c: eb.c }); else ej.push(eb);
    }

    // Camera
    if (myMass > 0) {
      const tx = mcx / myMass, ty = mcy / myMass;
      const k = 1 - Math.pow(0.002, dt);
      const vw = viewWidth(this.me.mass);
      const targetZoom = Math.max(this.r.W / vw, this.r.H / (vw * 0.75));
      if (this.camSnap) { this.camSnap = false; this.cam.x = tx; this.cam.y = ty; this.cam.zoom = targetZoom; }
      this.cam.x += (tx - this.cam.x) * k; this.cam.y += (ty - this.cam.y) * k;
      this.cam.zoom += (targetZoom - this.cam.zoom) * (1 - Math.pow(0.02, dt));
      s.me = { x: tx, y: ty };
    }
    // Input -> world target
    const d = this.input.desired(this.r.W, this.r.H);
    if (d.mode === 'point') { this.target.x = this.cam.x + (d.x - this.r.W / 2) / this.cam.zoom; this.target.y = this.cam.y + (d.y - this.r.H / 2) / this.cam.zoom; }
    else if (d.mode === 'vec' && s.me) { const reach = 400 / Math.sqrt(this.cam.zoom); this.target.x = s.me.x + d.dx * reach; this.target.y = s.me.y + d.dy * reach; }
    else if (s.me) { this.target.x = s.me.x; this.target.y = s.me.y; }
    s.joy = this.input.joy;

    // Effects
    this.shake *= Math.pow(0.02, dt); this.flash *= Math.pow(0.02, dt); if (this.vignette > 0 && this.result) this.vignette = Math.min(1, this.vignette + dt); else this.vignette *= Math.pow(0.1, dt);
    s.shake = this.shake; s.flash = this.flash; s.vignette = this.vignette; s.time = now / 1000;
    for (const p of this.particles) { if (p.life <= 0) continue; p.life -= dt * 1.6; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.9; p.vy *= 0.9; }
    for (const f of this.floaters) { if (f.life <= 0) continue; f.life -= dt * 0.9; f.y -= 40 * dt / this.cam.zoom; }
    if (this.floaters.length > 40) this.floaters.splice(0, this.floaters.length - 40);

    this.sendInput(now);
    this.hud.update(this, myMass);
  }

  burst(x, y, n, color, speed) {
    for (let i = 0; i < n; i++) {
      const p = this.particles[this.pi]; this.pi = (this.pi + 1) % P_COUNT;
      const a = Math.random() * Math.PI * 2, v = speed * (0.3 + Math.random() * 0.7);
      p.x = x; p.y = y; p.vx = Math.cos(a) * v; p.vy = Math.sin(a) * v; p.life = 0.6 + Math.random() * 0.5; p.size = 3 + Math.random() * 6; p.color = color;
    }
  }
  floater(x, y, text, size, color) { this.floaters.push({ x, y, text, size, color, life: 1.4 }); }

  potential() { return Math.floor(this.stake * this.me.mult * (1 + Math.min(C.STREAK_MAX, this.streak || 0) * C.STREAK_PAYOUT_BONUS)); }
}
