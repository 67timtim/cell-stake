// CELL — Bank / Risk / payout math. Pure functions over a plain account object.
// The server is the only place these mutate a real account. The browser runs
// them too, but only in offline practice mode against its own local store.
import { CONFIG as C, TIER_FOR_RISK } from './config.js';

export function newAccount(now = Date.now()) {
  return {
    v: 1,
    bank: C.START_BANK,
    bestBank: C.START_BANK,
    streak: 0,
    lastAllowanceAt: now,       // creation counts as today's allowance
    adDay: '', adAllowance: 0, adReenter: 0,
    skin: 0,
    stats: { biggestExtraction: 0, bestMult: 0, longestStreak: 0, playersEaten: 0, rounds: 0, extractions: 0, deaths: 0 },
    createdAt: now,
  };
}

// Returns amount granted (0 if none).
export function applyDailyAllowance(acct, now = Date.now()) {
  if (now - (acct.lastAllowanceAt || 0) >= C.DAILY_MS) {
    acct.lastAllowanceAt = now;
    addBank(acct, C.DAILY_ALLOWANCE);
    return C.DAILY_ALLOWANCE;
  }
  return 0;
}

export function addBank(acct, amount) {
  acct.bank = Math.max(C.BANK_FLOOR, Math.round(acct.bank + amount));
  if (acct.bank > acct.bestBank) acct.bestBank = acct.bank;
  return acct.bank;
}

export function isValidRisk(pct) { return C.RISK_TIERS.includes(pct); }

export function stakeFor(bank, riskPct) {
  const raw = Math.floor(bank * riskPct / 100);
  return Math.max(C.MIN_STAKE, Math.min(bank, raw));
}

export const tierFor = TIER_FOR_RISK;

// Deduct stake. Bank never drops below the mercy floor.
export function enterRound(acct, riskPct) {
  if (!isValidRisk(riskPct)) throw new Error('bad risk');
  const stake = stakeFor(acct.bank, riskPct);
  acct.bank = Math.max(C.BANK_FLOOR, acct.bank - stake);
  acct.stats.rounds++;
  return { stake, tier: tierFor(riskPct) };
}

export function payoutFor(stake, mult, streak) {
  const bonus = 1 + Math.min(C.STREAK_MAX, streak) * C.STREAK_PAYOUT_BONUS;
  return Math.floor(stake * mult * bonus);
}

export function settleExtraction(acct, stake, mult) {
  const payout = payoutFor(stake, mult, acct.streak);
  const streakBefore = acct.streak;
  addBank(acct, payout);
  if (mult >= 1) acct.streak = Math.min(C.STREAK_MAX, acct.streak + 1);
  acct.stats.extractions++;
  if (payout > acct.stats.biggestExtraction) acct.stats.biggestExtraction = payout;
  if (mult > acct.stats.bestMult) acct.stats.bestMult = mult;
  if (acct.streak > acct.stats.longestStreak) acct.stats.longestStreak = acct.streak;
  return { payout, profit: payout - stake, streakBefore, streak: acct.streak };
}

export function settleDeath(acct, stake, kills) {
  acct.streak = 0;
  acct.stats.deaths++;
  acct.stats.playersEaten += kills || 0;
  addBank(acct, 0); // enforce floor
  return { lost: stake };
}

export function unlockedSkinCount(acct) {
  let n = 1; // default skin always
  for (const m of C.SKIN_MILESTONES) if (acct.bestBank >= m) n++;
  return n;
}

// Public projection of an account safe to send to the client.
export function accountView(acct) {
  return {
    bank: acct.bank, bestBank: acct.bestBank, streak: acct.streak, skin: acct.skin,
    stats: acct.stats, skinsUnlocked: unlockedSkinCount(acct),
    nextAllowanceAt: (acct.lastAllowanceAt || 0) + C.DAILY_MS,
  };
}
