// Basic name filter. Not exhaustive by design; the server also runs it.
const BAD = ['fuck', 'shit', 'cunt', 'bitch', 'nigg', 'fag', 'dick', 'cock', 'pussy', 'whore', 'slut', 'rape', 'nazi', 'hitler', 'retard', 'twat', 'wank', 'jizz', 'cum', 'anal', 'penis', 'vagina', 'porn', 'sex'];
const LEET = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's', '!': 'i' };

export function isClean(name) {
  const norm = name.toLowerCase().replace(/[^a-z0-9@$!]/g, '').replace(/[013457@$!]/g, ch => LEET[ch] || ch);
  return !BAD.some(w => norm.includes(w));
}

export function cleanName(raw, fallback = 'cell') {
  let n = String(raw || '').replace(/[^\w \-.]/g, '').trim().slice(0, 14);
  if (!n) n = fallback;
  if (!isClean(n)) n = fallback;
  return n;
}
