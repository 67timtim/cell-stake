// CELL — bot AI. Bots are ordinary players in the World with a `brain`.
// Behaviour: seek pellet clusters; flee bigger cells nearby; chase smaller
// cells nearby; occasionally attempt an extraction when large.
import { CONFIG as C } from './config.js';

export const BOT_NAMES = [
  'mira', 'Kap0w', 'juno_', 'ozzy', 'BLINK', 'tessa', 'Rook', 'quill', 'nova9', 'Pip',
  'sable', 'FLUX', 'dax', 'lumen', 'Zed', 'orla', 'kit', 'VANTA', 'ember', 'moss',
  'yuki', 'ARC', 'faye', 'bramble', 'Nix', 'toast', 'halo', 'DRIFT', 'iris', 'wren',
  'gale', 'Puck', 'sol', 'REM', 'ada', 'kobe_', 'lark', 'Vex', 'onyx', 'tally',
];

export function pickBotName(rng, taken) {
  for (let i = 0; i < 20; i++) {
    const n = BOT_NAMES[(rng() * BOT_NAMES.length) | 0];
    if (!taken.has(n)) return n;
  }
  return BOT_NAMES[(rng() * BOT_NAMES.length) | 0] + ((rng() * 90 + 10) | 0);
}

export function makeBrain(rng) {
  return {
    nextThink: 0,
    wanderX: rng() * C.MAP_SIZE, wanderY: rng() * C.MAP_SIZE,
    wanderUntil: 0,
    extractRing: -1,
    aggression: 0.35 + rng() * 0.5,     // personality: how eagerly it chases
    caution: 0.6 + rng() * 0.6,          // how far it flees
    splitCooldown: 0,
  };
}

export function updateBots(world, dt) {
  const t = world.time;
  const rng = world.rng;
  for (const p of world.players.values()) {
    if (!p.bot || !p.alive) continue;
    const b = p.brain || (p.brain = makeBrain(rng));
    b.splitCooldown -= dt;
    p.lastInputAt = t;
    if (t < b.nextThink) continue;
    b.nextThink = t + C.BOT_THINK_INTERVAL * (0.7 + rng() * 0.6);

    // Largest own cell drives decisions.
    let main = null;
    for (const cid of p.cells) { const c = world.cells.get(cid); if (!main || c.mass > main.mass) main = c; }
    if (!main) continue;
    const myMass = main.mass;

    // Scan nearby cells once.
    let threat = null, threatD = Infinity, prey = null, preyScore = -Infinity;
    const scan = Math.max(C.BOT_FLEE_RANGE, C.BOT_CHASE_RANGE) + main.r;
    world.cellGrid.query(main.x - scan, main.y - scan, main.x + scan, main.y + scan, (o) => {
      if (o.owner === p.id) return;
      const op = world.players.get(o.owner);
      if (!op || !op.alive || t < op.spawnProtUntil) return;
      const d = Math.hypot(o.x - main.x, o.y - main.y);
      if (o.mass >= myMass * C.BOT_FLEE_RATIO && d - o.r < C.BOT_FLEE_RANGE * b.caution) {
        if (d < threatD) { threatD = d; threat = o; }
      } else if (o.mass <= myMass * C.BOT_CHASE_RATIO && o.mass >= myMass * C.BOT_MIN_PREY_FRACTION && d < C.BOT_CHASE_RANGE + main.r) {
        const score = o.mass / (d + 50);
        if (score > preyScore) { preyScore = score; prey = o; }
      }
    });

    let tx, ty, mode;
    if (threat) {
      // Flee: away from threat, biased toward map centre when near a wall.
      const dx = main.x - threat.x, dy = main.y - threat.y;
      const d = Math.hypot(dx, dy) || 1;
      tx = main.x + (dx / d) * 800; ty = main.y + (dy / d) * 800;
      const m = 300;
      if (tx < m || tx > world.size - m || ty < m || ty > world.size - m) {
        // slide along the wall: pick the perpendicular direction with more room
        const px = -dy / d, py = dx / d;
        const c1x = main.x + px * 800, c1y = main.y + py * 800;
        const c2x = main.x - px * 800, c2y = main.y - py * 800;
        const room = (x, y) => Math.min(x, world.size - x, y, world.size - y);
        if (room(c1x, c1y) > room(c2x, c2y)) { tx = c1x; ty = c1y; } else { tx = c2x; ty = c2y; }
      }
      mode = 'flee';
      b.extractRing = -1;
    } else if (b.extractRing >= 0) {
      const ring = world.rings[b.extractRing];
      tx = ring.x; ty = ring.y; mode = 'extract';
      if (rng() < 0.02) b.extractRing = -1; // give up sometimes
    } else if (prey && rng() < b.aggression) {
      tx = prey.x; ty = prey.y; mode = 'chase';
      // Split-attack if it would land and we stay safe-ish.
      const d = Math.hypot(prey.x - main.x, prey.y - main.y);
      if (b.splitCooldown <= 0 && p.cells.size <= 2 && myMass > 80 && myMass / 2 >= prey.mass * C.EAT_RATIO && d < 350 && d > main.r && rng() < 0.35 * b.aggression) {
        p.wantSplit = true; b.splitCooldown = 4;
      }
    } else {
      // Consider extraction when big.
      if (myMass >= C.BOT_EXTRACT_MASS && rng() < C.BOT_EXTRACT_CHANCE) {
        let best = -1, bd = Infinity;
        for (const r of world.rings) { const d = Math.hypot(r.x - main.x, r.y - main.y); if (d < bd) { bd = d; best = r.id; } }
        b.extractRing = best;
        tx = world.rings[best].x; ty = world.rings[best].y; mode = 'extract';
      } else {
        // Seek pellet cluster: sample pellets in a wide box, pick densest direction.
        let bestX = 0, bestY = 0, bestN = -1;
        const R = 700;
        const sectors = new Float32Array(8);
        const sx = new Float32Array(8), sy = new Float32Array(8);
        world.pelletGrid.query(main.x - R, main.y - R, main.x + R, main.y + R, (pl) => {
          const dx = pl.x - main.x, dy = pl.y - main.y;
          const d2 = dx * dx + dy * dy;
          if (d2 > R * R) return;
          const a = Math.atan2(dy, dx);
          const s = ((a + Math.PI) / (2 * Math.PI) * 8) | 0;
          const i = Math.min(7, s);
          sectors[i] += 1 / (1 + d2 / 40000);
          sx[i] += pl.x; sy[i] += pl.y;
        });
        let cnt = 0;
        for (let i = 0; i < 8; i++) if (sectors[i] > bestN) { bestN = sectors[i]; cnt = i; }
        if (bestN > 0.5) {
          // centroid of that sector's pellets
          let n = 0; const s = cnt;
          world.pelletGrid.query(main.x - R, main.y - R, main.x + R, main.y + R, (pl) => {
            const dx = pl.x - main.x, dy = pl.y - main.y;
            const a = Math.atan2(dy, dx);
            const si = Math.min(7, ((a + Math.PI) / (2 * Math.PI) * 8) | 0);
            if (si === s) { n++; bestX += pl.x; bestY += pl.y; }
          });
          if (n > 0) { tx = bestX / n; ty = bestY / n; mode = 'graze'; }
        }
        if (mode !== 'graze') {
          if (t > b.wanderUntil || Math.hypot(b.wanderX - main.x, b.wanderY - main.y) < 150) {
            b.wanderX = 300 + rng() * (world.size - 600); b.wanderY = 300 + rng() * (world.size - 600);
            b.wanderUntil = t + 6 + rng() * 6;
          }
          tx = b.wanderX; ty = b.wanderY; mode = 'wander';
        }
      }
    }
    b.mode = mode;
    p.target.x = Math.max(0, Math.min(world.size, tx));
    p.target.y = Math.max(0, Math.min(world.size, ty));
  }
}
