// CELL — authoritative arena simulation. Pure logic, no DOM, no sockets.
// Runs on the server (authoritative) and in the browser (offline practice mode).
import { CONFIG as C } from './config.js';

export const radiusOf = (mass) => Math.sqrt(mass) * C.RADIUS_SCALE;
export const speedOf = (mass) => C.BASE_SPEED * Math.pow(Math.max(mass, 1), C.SPEED_EXP);
export const viewWidth = (totalMass) =>
  Math.min(C.VIEW_MAX, C.VIEW_BASE * Math.pow(Math.max(totalMass, C.START_MASS) / C.START_MASS, C.VIEW_EXP));

// Deterministic-enough RNG (mulberry32) so a room can be seeded for tests.
export function makeRng(seed = (Math.random() * 2 ** 32) >>> 0) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PELLET_COLORS = 8; // client maps index -> palette

class Grid {
  constructor(size, cellSize) {
    this.cs = cellSize;
    this.n = Math.ceil(size / cellSize) + 1;
    this.buckets = new Array(this.n * this.n);
    for (let i = 0; i < this.buckets.length; i++) this.buckets[i] = [];
  }
  idx(x, y) {
    const gx = Math.max(0, Math.min(this.n - 1, (x / this.cs) | 0));
    const gy = Math.max(0, Math.min(this.n - 1, (y / this.cs) | 0));
    return gy * this.n + gx;
  }
  clear() { for (const b of this.buckets) b.length = 0; }
  insert(o) { this.buckets[this.idx(o.x, o.y)].push(o); }
  remove(o) {
    const b = this.buckets[this.idx(o.x, o.y)];
    const i = b.indexOf(o);
    if (i >= 0) { b[i] = b[b.length - 1]; b.pop(); }
  }
  // Calls fn(o) for every object whose bucket overlaps the box.
  query(x0, y0, x1, y1, fn) {
    const gx0 = Math.max(0, (x0 / this.cs) | 0), gy0 = Math.max(0, (y0 / this.cs) | 0);
    const gx1 = Math.min(this.n - 1, (x1 / this.cs) | 0), gy1 = Math.min(this.n - 1, (y1 / this.cs) | 0);
    for (let gy = gy0; gy <= gy1; gy++) {
      for (let gx = gx0; gx <= gx1; gx++) {
        const b = this.buckets[gy * this.n + gx];
        for (let i = 0; i < b.length; i++) fn(b[i]);
      }
    }
  }
}

export class World {
  constructor({ tier = 'casual', seed } = {}) {
    this.tier = tier;
    this.lobby = C.LOBBIES[tier];
    this.rng = makeRng(seed);
    this.size = C.MAP_SIZE;
    this.time = 0;
    this.tick = 0;
    this.nextId = 1;
    this.players = new Map();
    this.cells = new Map();
    this.pellets = new Map();
    this.ejected = new Map();
    this.rings = C.RINGS.map((r, i) => ({ id: i, x: r.x, y: r.y, r: C.RING_RADIUS, channelers: 0, bestProgress: 0 }));
    this.events = [];
    this.pelletTarget = Math.round(C.PELLET_COUNT * this.lobby.pelletScale);
    this.cellGrid = new Grid(this.size, 400);
    this.pelletGrid = new Grid(this.size, 100);
    this.ejectGrid = new Grid(this.size, 200);
    this._maxCellR = 1;
    while (this.pellets.size < this.pelletTarget) this.spawnPellet();
  }

  id() { return this.nextId++; }

  // ---- Spawning ------------------------------------------------------------
  spawnPellet() {
    const p = { id: this.id(), x: 20 + this.rng() * (this.size - 40), y: 20 + this.rng() * (this.size - 40), c: (this.rng() * PELLET_COLORS) | 0 };
    this.pellets.set(p.id, p);
    this.pelletGrid.insert(p);
    return p;
  }

  safeSpawnPoint() {
    // Try a few random spots away from big cells and rings.
    let best = null, bestScore = -1;
    for (let i = 0; i < 12; i++) {
      const x = 200 + this.rng() * (this.size - 400), y = 200 + this.rng() * (this.size - 400);
      let score = 1e9;
      for (const c of this.cells.values()) {
        if (c.mass < C.START_MASS * 1.25) continue;
        const d = Math.hypot(c.x - x, c.y - y) - c.r;
        if (d < score) score = d;
      }
      if (score > bestScore) { bestScore = score; best = { x, y }; }
      if (score > 900) break;
    }
    return best;
  }

  addPlayer({ id, name, bot = false, skin = 0, stake = 0, streak = 0 }) {
    const p = {
      id, name, bot, skin, stake, streak,
      cells: new Set(),
      target: { x: 0, y: 0 },
      wantSplit: false, wantEject: false, lastSeq: 0,
      joinedAt: this.time, lastInputAt: this.time,
      spawnProtUntil: this.time + C.SPAWN_PROTECT_SEC,
      peakMass: C.START_MASS, kills: 0, mult: 0, payoutMult: 0,
      extractRing: -1, extractT: 0, hurtAt: -1,
      alive: true, mass: C.START_MASS, cx: 0, cy: 0,
      brain: null,
    };
    const sp = this.safeSpawnPoint();
    p.target.x = sp.x; p.target.y = sp.y;
    this.players.set(id, p);
    this.spawnCell(p, sp.x, sp.y, C.START_MASS);
    this.recomputePlayer(p);
    return p;
  }

  spawnCell(p, x, y, mass) {
    const c = { id: this.id(), owner: p.id, x, y, mass, r: radiusOf(mass), bx: 0, by: 0, mergeAt: 0 };
    this.cells.set(c.id, c);
    p.cells.add(c.id);
    return c;
  }

  removePlayer(id) {
    const p = this.players.get(id);
    if (!p) return;
    for (const cid of p.cells) this.cells.delete(cid);
    this.players.delete(id);
  }

  setInput(id, inp) {
    const p = this.players.get(id);
    if (!p || !p.alive) return;
    if (typeof inp.x === 'number' && typeof inp.y === 'number' && isFinite(inp.x) && isFinite(inp.y)) {
      p.target.x = Math.max(0, Math.min(this.size, inp.x));
      p.target.y = Math.max(0, Math.min(this.size, inp.y));
    }
    if (inp.split) p.wantSplit = true;
    if (inp.eject) p.wantEject = true;
    if (typeof inp.seq === 'number') p.lastSeq = inp.seq;
    p.lastInputAt = this.time;
  }

  // ---- Main step -----------------------------------------------------------
  step(dt) {
    this.time += dt;
    this.tick++;
    const t = this.time;

    // Actions
    for (const p of this.players.values()) {
      if (!p.alive) continue;
      if (p.wantSplit) { this.split(p); p.wantSplit = false; }
      if (p.wantEject) { this.eject(p); p.wantEject = false; }
    }

    // Movement
    for (const p of this.players.values()) {
      if (!p.alive) continue;
      for (const cid of p.cells) {
        const c = this.cells.get(cid);
        const dx = p.target.x - c.x, dy = p.target.y - c.y;
        const dist = Math.hypot(dx, dy);
        const sp = speedOf(c.mass);
        if (dist > 0.5) {
          const f = Math.min(1, dist / Math.max(20, c.r));
          const v = sp * f / dist;
          c.x += dx * v * dt; c.y += dy * v * dt;
        }
        c.x += c.bx * dt; c.y += c.by * dt;
        const damp = Math.exp(-C.BOOST_DAMP * dt);
        c.bx *= damp; c.by *= damp;
        if (Math.abs(c.bx) < 1) c.bx = 0;
        if (Math.abs(c.by) < 1) c.by = 0;
        if (c.x < c.r) c.x = c.r; else if (c.x > this.size - c.r) c.x = this.size - c.r;
        if (c.y < c.r) c.y = c.r; else if (c.y > this.size - c.r) c.y = this.size - c.r;
      }
      if (p.cells.size > 1) this.resolveOwnCells(p);
    }

    // Ejected mass movement
    for (const e of this.ejected.values()) {
      e.x += e.vx * dt; e.y += e.vy * dt;
      const damp = Math.exp(-C.BOOST_DAMP * dt);
      e.vx *= damp; e.vy *= damp;
      if (e.x < 8) { e.x = 8; e.vx = -e.vx; } else if (e.x > this.size - 8) { e.x = this.size - 8; e.vx = -e.vx; }
      if (e.y < 8) { e.y = 8; e.vy = -e.vy; } else if (e.y > this.size - 8) { e.y = this.size - 8; e.vy = -e.vy; }
    }

    // Rebuild dynamic grids
    this.cellGrid.clear();
    this._maxCellR = 1;
    for (const c of this.cells.values()) { this.cellGrid.insert(c); if (c.r > this._maxCellR) this._maxCellR = c.r; }
    this.ejectGrid.clear();
    for (const e of this.ejected.values()) this.ejectGrid.insert(e);

    // Eating
    this.eatPhase();

    // Decay + per-player bookkeeping
    for (const p of this.players.values()) {
      if (!p.alive) continue;
      for (const cid of p.cells) {
        const c = this.cells.get(cid);
        if (c.mass > C.DECAY_ABOVE) c.mass -= c.mass * C.DECAY_RATE * dt;
        c.r = radiusOf(c.mass);
      }
      this.recomputePlayer(p);
      this.updateMultiplier(p);
      // AFK
      if (!p.bot && t - p.lastInputAt > C.AFK_SECONDS) this.kill(p, null, 'afk');
    }

    // Extraction channels
    this.extractionPhase(dt);

    // Pellet respawn
    let n = 0;
    while (this.pellets.size < this.pelletTarget && n++ < C.PELLET_RESPAWN_PER_TICK) this.spawnPellet();
  }

  recomputePlayer(p) {
    let m = 0, cx = 0, cy = 0;
    for (const cid of p.cells) { const c = this.cells.get(cid); m += c.mass; cx += c.x * c.mass; cy += c.y * c.mass; }
    p.mass = m;
    if (m > 0) { p.cx = cx / m; p.cy = cy / m; }
    if (m > p.peakMass) p.peakMass = m;
  }

  updateMultiplier(p) {
    const survived = Math.floor((this.time - p.joinedAt) / 30) * C.MULT_PER_30S;
    const gain = Math.floor(Math.max(0, p.peakMass - C.START_MASS) / 100) * C.MULT_PER_100_MASS;
    const kills = p.kills * C.MULT_PER_KILL;
    const raw = (survived + gain + kills) * this.lobby.multRate;
    const cap = C.MULT_CAP + Math.min(C.STREAK_MAX, p.streak) * C.STREAK_CAP_BONUS;
    p.mult = Math.min(cap, Math.round(raw * 100) / 100);
  }

  // ---- Own-cell collision / merge -----------------------------------------
  resolveOwnCells(p) {
    const arr = [];
    for (const cid of p.cells) arr.push(this.cells.get(cid));
    for (let i = 0; i < arr.length; i++) {
      const a = arr[i];
      if (!this.cells.has(a.id)) continue;
      for (let j = i + 1; j < arr.length; j++) {
        const b = arr[j];
        if (!this.cells.has(b.id)) continue;
        const dx = b.x - a.x, dy = b.y - a.y;
        const d = Math.hypot(dx, dy);
        const canMerge = this.time >= a.mergeAt && this.time >= b.mergeAt;
        if (canMerge) {
          const big = a.mass >= b.mass ? a : b, small = big === a ? b : a;
          if (d < big.r - small.r * 0.3) {
            big.mass += small.mass; big.r = radiusOf(big.mass);
            this.cells.delete(small.id); p.cells.delete(small.id);
          }
        } else if (d < a.r + b.r && d > 0.001) {
          const overlap = a.r + b.r - d;
          const push = overlap * 0.5;
          const nx = dx / d, ny = dy / d;
          const ta = b.mass / (a.mass + b.mass), tb = 1 - ta;
          a.x -= nx * push * ta * 2; a.y -= ny * push * ta * 2;
          b.x += nx * push * tb * 2; b.y += ny * push * tb * 2;
        }
      }
    }
  }

  // ---- Split / Eject -------------------------------------------------------
  split(p) {
    const arr = [];
    for (const cid of p.cells) arr.push(this.cells.get(cid));
    arr.sort((a, b) => b.mass - a.mass);
    let count = arr.length;
    for (const c of arr) {
      if (count >= C.MAX_CELLS) break;
      if (c.mass < C.SPLIT_MIN_MASS) continue;
      const dx = p.target.x - c.x, dy = p.target.y - c.y;
      const d = Math.hypot(dx, dy) || 1;
      const nx = dx / d, ny = dy / d;
      const half = c.mass / 2;
      c.mass = half; c.r = radiusOf(half);
      c.mergeAt = this.time + C.MERGE_BASE_SEC + half * C.MERGE_PER_MASS_SEC;
      const nc = this.spawnCell(p, c.x + nx * c.r, c.y + ny * c.r, half);
      nc.bx = nx * C.SPLIT_BOOST; nc.by = ny * C.SPLIT_BOOST;
      nc.mergeAt = c.mergeAt;
      count++;
    }
    this.events.push({ t: 'split', p: p.id, x: p.cx, y: p.cy });
  }

  eject(p) {
    if (this.ejected.size > C.EJECT_MAX_ALIVE) return;
    let did = false;
    for (const cid of p.cells) {
      const c = this.cells.get(cid);
      if (c.mass < C.EJECT_MIN_MASS) continue;
      const dx = p.target.x - c.x, dy = p.target.y - c.y;
      const d = Math.hypot(dx, dy) || 1;
      const nx = dx / d, ny = dy / d;
      c.mass -= C.EJECT_COST; c.r = radiusOf(c.mass);
      const e = { id: this.id(), owner: p.id, x: c.x + nx * (c.r + 10), y: c.y + ny * (c.r + 10), vx: nx * C.EJECT_SPEED + c.bx, vy: ny * C.EJECT_SPEED + c.by, mass: C.EJECT_MASS, born: this.time, c: p.skin };
      this.ejected.set(e.id, e);
      did = true;
    }
    if (did) this.events.push({ t: 'eject', p: p.id, x: p.cx, y: p.cy });
  }

  // ---- Eating --------------------------------------------------------------
  eatPhase() {
    const t = this.time;
    // Iterate a stable array; cells may be deleted mid-loop.
    const cellsArr = Array.from(this.cells.values());
    cellsArr.sort((a, b) => b.mass - a.mass);
    for (const a of cellsArr) {
      if (!this.cells.has(a.id)) continue;
      const pa = this.players.get(a.owner);
      if (!pa || !pa.alive) continue;
      const r = a.r;
      // Pellets
      let gained = 0, ate = 0;
      this.pelletGrid.query(a.x - r, a.y - r, a.x + r, a.y + r, (pl) => {
        if (pl._dead) return;
        const dx = pl.x - a.x, dy = pl.y - a.y;
        if (dx * dx + dy * dy <= r * r) { pl._dead = true; gained += C.PELLET_MASS; ate++; this._toRemovePellets.push(pl); }
      });
      if (ate) {
        a.mass += gained;
        this.events.push({ t: 'pel', p: a.owner, x: a.x, y: a.y, n: ate });
      }
      // Ejected blobs
      this.ejectGrid.query(a.x - r, a.y - r, a.x + r, a.y + r, (e) => {
        if (e._dead || t - e.born < C.EJECT_EDIBLE_AFTER) return;
        const dx = e.x - a.x, dy = e.y - a.y;
        if (dx * dx + dy * dy <= r * r) { e._dead = true; a.mass += e.mass; this._toRemoveEject.push(e); }
      });
      // Other cells
      const protectedA = t < pa.spawnProtUntil;
      if (protectedA) continue;
      const q = r + this._maxCellR;
      this.cellGrid.query(a.x - q, a.y - q, a.x + q, a.y + q, (b) => {
        if (b === a || !this.cells.has(b.id) || b.owner === a.owner) return;
        if (a.mass < b.mass * C.EAT_RATIO) return;
        const pb = this.players.get(b.owner);
        if (!pb || !pb.alive || t < pb.spawnProtUntil) return;
        const dx = b.x - a.x, dy = b.y - a.y;
        if (dx * dx + dy * dy > r * r) return;
        this.eatCell(a, b, pa, pb);
      });
      a.r = radiusOf(a.mass);
    }
    for (const pl of this._toRemovePellets) { this.pellets.delete(pl.id); this.pelletGrid.remove(pl); }
    this._toRemovePellets.length = 0;
    for (const e of this._toRemoveEject) this.ejected.delete(e.id);
    this._toRemoveEject.length = 0;
  }
  _toRemovePellets = [];
  _toRemoveEject = [];

  eatCell(a, b, pa, pb) {
    a.mass += b.mass * C.EAT_GAIN;
    a.r = radiusOf(a.mass);
    this.cells.delete(b.id);
    pb.cells.delete(b.id);
    pb.hurtAt = this.time;
    this.events.push({ t: 'eat', p: pa.id, v: pb.id, x: b.x, y: b.y, m: b.mass, c: pb.skin });
    if (pb.cells.size === 0) {
      if (!pb.bot) pa.kills++;
      this.kill(pb, pa, 'eaten');
    }
  }

  kill(p, killer, reason) {
    if (!p.alive) return;
    p.alive = false;
    for (const cid of p.cells) this.cells.delete(cid);
    p.cells.clear();
    this.recomputePlayerDead(p);
    this.events.push({ t: 'death', p: p.id, by: killer ? killer.id : null, byName: killer ? killer.name : null, reason, x: p.cx, y: p.cy });
  }
  recomputePlayerDead(p) { p.mass = 0; }

  // ---- Extraction ----------------------------------------------------------
  extractionPhase(dt) {
    for (const ring of this.rings) { ring.channelers = 0; ring.bestProgress = 0; }
    for (const p of this.players.values()) {
      if (!p.alive) continue;
      // Every cell of the player must be inside a single ring.
      let ringId = -1;
      for (const ring of this.rings) {
        let all = p.cells.size > 0;
        for (const cid of p.cells) {
          const c = this.cells.get(cid);
          if (Math.hypot(c.x - ring.x, c.y - ring.y) > ring.r) { all = false; break; }
        }
        if (all) { ringId = ring.id; break; }
      }
      const hurt = p.hurtAt >= 0 && this.time - p.hurtAt < 0.5;
      if (ringId < 0 || hurt) {
        if (p.extractRing >= 0 && p.extractT > 0.2) this.events.push({ t: 'chanbreak', p: p.id });
        p.extractRing = -1; p.extractT = 0;
        continue;
      }
      if (p.extractRing !== ringId) { p.extractRing = ringId; p.extractT = 0; this.events.push({ t: 'chanstart', p: p.id, ring: ringId }); }
      p.extractT += dt;
      const ring = this.rings[ringId];
      ring.channelers++;
      ring.bestProgress = Math.max(ring.bestProgress, p.extractT / C.EXTRACT_SECONDS);
      if (p.extractT >= C.EXTRACT_SECONDS) {
        p.alive = false;
        for (const cid of p.cells) this.cells.delete(cid);
        p.cells.clear();
        p.mass = 0;
        this.events.push({ t: 'extract', p: p.id, ring: ringId, x: ring.x, y: ring.y, mult: p.mult });
      }
    }
  }

  drainEvents() { const e = this.events; this.events = []; return e; }

  // ---- Queries -------------------------------------------------------------
  // Everything a given viewer should receive: box = viewport (+margin).
  queryBox(x0, y0, x1, y1, out) {
    out.cells.length = 0; out.pellets.length = 0; out.ejected.length = 0;
    for (const c of this.cells.values()) if (c.x + c.r >= x0 && c.x - c.r <= x1 && c.y + c.r >= y0 && c.y - c.r <= y1) out.cells.push(c);
    this.pelletGrid.query(x0, y0, x1, y1, (p) => { if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1) out.pellets.push(p); });
    for (const e of this.ejected.values()) if (e.x >= x0 && e.x <= x1 && e.y >= y0 && e.y <= y1) out.ejected.push(e);
    return out;
  }
}
