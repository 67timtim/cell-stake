// CELL — single source of truth for every gameplay constant.
// Shared by the browser client (offline/practice mode + rendering) and the
// authoritative Node server. Tune here, nowhere else.

export const CONFIG = {
  // ---- Arena -------------------------------------------------------------
  MAP_SIZE: 6000,            // world units, square
  TICK_RATE: 20,             // authoritative simulation ticks per second
  GRID_STEP: 100,            // background grid spacing (client only)

  PELLET_COUNT: 900,         // pellets alive at all times (casual)
  PELLET_MASS: 1,
  PELLET_RESPAWN_PER_TICK: 8,

  START_MASS: 30,
  RADIUS_SCALE: 6,           // radius = sqrt(mass) * RADIUS_SCALE
  BASE_SPEED: 700,           // speed = BASE_SPEED * mass^-0.22  (units/sec)
  SPEED_EXP: -0.22,

  EAT_RATIO: 1.25,           // eater mass >= EAT_RATIO * prey mass
  EAT_GAIN: 0.85,            // fraction of eaten mass absorbed

  SPLIT_MIN_MASS: 36,
  SPLIT_BOOST: 780,          // launch speed of the front half (units/sec)
  BOOST_DAMP: 4.5,           // exponential damping of boosts
  MAX_CELLS: 8,
  MERGE_BASE_SEC: 15,
  MERGE_PER_MASS_SEC: 0.02,

  EJECT_MASS: 15,
  EJECT_COST: 18,
  EJECT_MIN_MASS: 35,
  EJECT_SPEED: 900,
  EJECT_EDIBLE_AFTER: 0.35,  // seconds before an ejected blob can be eaten
  EJECT_MAX_ALIVE: 400,

  DECAY_ABOVE: 200,
  DECAY_RATE: 0.002,         // fraction per second above DECAY_ABOVE

  // Camera / area of interest
  VIEW_BASE: 1500,           // world-units of width visible at START_MASS
  VIEW_EXP: 0.30,
  VIEW_MAX: 6600,
  AOI_MARGIN: 0.20,          // server sends viewport + 20%

  // ---- Stake layer -------------------------------------------------------
  START_BANK: 500,
  DAILY_ALLOWANCE: 300,
  DAILY_MS: 24 * 60 * 60 * 1000,
  BANK_FLOOR: 100,           // mercy floor
  MIN_STAKE: 50,
  RISK_TIERS: [10, 25, 50, 100],   // percent of bank

  LOBBIES: {
    casual: { minRisk: 10, maxRisk: 25, maxPlayers: 40, pelletScale: 1.0, multRate: 1.0 },
    high:   { minRisk: 50, maxRisk: 100, maxPlayers: 20, pelletScale: 0.7, multRate: 1.5 },
  },
  MIN_ENTITIES: 15,          // lobbies auto-fill with bots to this count

  MULT_PER_30S: 0.1,
  MULT_PER_100_MASS: 0.2,
  MULT_PER_KILL: 0.5,
  MULT_CAP: 5.0,

  RINGS: [                   // fixed extraction rings
    { x: 1400, y: 1500 },
    { x: 4600, y: 1500 },
    { x: 3000, y: 4700 },
  ],
  RING_RADIUS: 230,
  EXTRACT_SECONDS: 3,

  STREAK_PAYOUT_BONUS: 0.10, // +10% payout per streak level
  STREAK_CAP_BONUS: 0.5,     // +0.5x multiplier cap per streak level
  STREAK_MAX: 5,

  SPAWN_PROTECT_SEC: 5,
  AFK_SECONDS: 60,
  RECONNECT_GRACE_SEC: 60,   // disconnected players stay alive this long (AFK rule)

  // ---- Progression -------------------------------------------------------
  SKIN_MILESTONES: [1000, 2500, 5000, 10000, 25000, 50000],

  // ---- Bots --------------------------------------------------------------
  BOT_FLEE_RATIO: 1.25,
  BOT_FLEE_RANGE: 600,
  BOT_CHASE_RATIO: 0.8,
  BOT_CHASE_RANGE: 420,
  BOT_MIN_PREY_FRACTION: 0.3, // bots ignore prey smaller than this fraction of their mass
  BOT_THINK_INTERVAL: 0.25,  // seconds between decisions
  BOT_EXTRACT_MASS: 350,     // bots may wander to a ring above this mass
  BOT_EXTRACT_CHANCE: 0.15,  // per think, when eligible
  BOT_RESPAWN_DELAY: 3,      // seconds

  // ---- Networking --------------------------------------------------------
  INPUT_RATE: 30,            // max client inputs per second
  INTERP_DELAY_MS: 100,      // render this far behind latest snapshot
  META_EVERY_TICKS: 10,      // player metadata (names/mult) refresh

  // ---- Portal hooks (disabled by default) --------------------------------
  ADS_ENABLED: false,
  AD_EXTRA_ALLOWANCE_PER_DAY: 1,
  AD_REENTER_PER_DAY: 2,
  AD_REENTER_REFUND: 0.25,
};

export const TIER_FOR_RISK = (riskPct) =>
  riskPct >= CONFIG.LOBBIES.high.minRisk ? 'high' : 'casual';
