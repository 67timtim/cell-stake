// CELL — a Room = one World + bots + per-viewer area-of-interest snapshots.
// Host-agnostic: the Node server and the browser's offline mode both drive it.
//   send(playerId, msg)        -> deliver a message to a human viewer
//   onResult(playerId, result) -> a human's round ended (extract/death); host settles the account
import { CONFIG as C } from './config.js';
import { World, viewWidth } from './sim.js';
import { updateBots, pickBotName, makeBrain } from './bots.js';

let ROOM_SEQ = 1;

export class Room {
  constructor({ tier = 'casual', send, onResult, seed, id } = {}) {
    this.id = id || `${tier}-${ROOM_SEQ++}`;
    this.tier = tier;
    this.lobby = C.LOBBIES[tier];
    this.world = new World({ tier, seed });
    this.send = send || (() => {});
    this.onResult = onResult || (() => {});
    this.viewers = new Map();       // playerId -> viewer state (humans only)
    this.botRespawns = [];          // times at which to spawn a bot
    this.nextPlayerId = 1;
    this.leaderboard = [];
    this._q = { cells: [], pellets: [], ejected: [] };
    this.fillBots();
  }

  humanCount() { return this.viewers.size; }
  isFull() { return this.humanCount() >= this.lobby.maxPlayers; }
  aliveCount() { let n = 0; for (const p of this.world.players.values()) if (p.alive) n++; return n; }

  // ---- Bots ----------------------------------------------------------------
  fillBots() {
    const want = Math.max(0, C.MIN_ENTITIES - this.humanCount());
    let bots = 0;
    for (const p of this.world.players.values()) if (p.bot && p.alive) bots++;
    const pending = this.botRespawns.length;
    for (let i = bots + pending; i < want; i++) this.spawnBot();
  }
  spawnBot() {
    const taken = new Set();
    for (const p of this.world.players.values()) taken.add(p.name);
    const rng = this.world.rng;
    const p = this.world.addPlayer({
      id: this.nextPlayerId++, name: pickBotName(rng, taken), bot: true,
      skin: (rng() * 12) | 0, stake: 0, streak: 0,
    });
    p.brain = makeBrain(rng);
    return p;
  }

  // ---- Humans --------------------------------------------------------------
  join({ name, skin, stake, streak }) {
    const id = this.nextPlayerId++;
    this.world.addPlayer({ id, name, bot: false, skin, stake, streak });
    this.viewers.set(id, { id, knownPellets: new Set(), metaSent: new Map(), lastLbTick: -999, joinedTick: this.world.tick });
    return id;
  }

  // (Re)send the 'joined' handshake and reset this viewer's delta state so a
  // fresh client receives the full picture. Used on join and on reconnect.
  resendJoin(id) {
    const v = this.viewers.get(id);
    const p = this.world.players.get(id);
    if (!v || !p) return;
    v.knownPellets.clear(); v.metaSent.clear(); v.lastLbTick = -999;
    this.send(id, {
      t: 'joined', room: this.id, tier: this.tier, id, stake: p.stake,
      map: C.MAP_SIZE, rings: this.world.rings.map(r => ({ x: r.x, y: r.y, r: r.r })),
      time: Math.round(this.world.time * 1000),
    });
  }

  input(id, inp) { this.world.setInput(id, inp); }

  // Voluntary leave = forfeit (same as death).
  leave(id, reason = 'left') {
    const p = this.world.players.get(id);
    if (!p) { this.viewers.delete(id); return; }
    if (p.alive) this.world.kill(p, null, reason);
    // death event will be processed on next tick's event pass; process now instead:
    this.processEvents(this.world.drainEvents());
  }

  hasPlayer(id) { return this.viewers.has(id); }

  // ---- Tick ----------------------------------------------------------------
  tick() {
    const dt = 1 / C.TICK_RATE;
    const w = this.world;
    updateBots(w, dt);
    w.step(dt);
    const events = w.drainEvents();
    this.processEvents(events);
    // Bot respawns
    while (this.botRespawns.length && this.botRespawns[0] <= w.time) { this.botRespawns.shift(); this.spawnBot(); }
    this.fillBots();
    if (w.tick % 20 === 0) this.updateLeaderboard();
    this.broadcast(events);
  }

  processEvents(events) {
    for (const ev of events) {
      if (ev.t !== 'death' && ev.t !== 'extract') continue;
      const p = this.world.players.get(ev.p);
      if (!p) continue;
      if (p.bot) {
        this.world.removePlayer(p.id);
        this.botRespawns.push(this.world.time + C.BOT_RESPAWN_DELAY);
        continue;
      }
      const survived = Math.round(this.world.time - p.joinedAt);
      const base = { stake: p.stake, mult: p.mult, kills: p.kills, survived, peakMass: Math.round(p.peakMass), tier: this.tier };
      if (ev.t === 'extract') this.onResult(p.id, { kind: 'extract', ...base });
      else this.onResult(p.id, { kind: 'death', reason: ev.reason, byName: ev.byName, ...base });
      this.world.removePlayer(p.id);
      this.viewers.delete(p.id);
    }
  }

  updateLeaderboard() {
    const arr = [];
    for (const p of this.world.players.values()) if (p.alive) arr.push(p);
    arr.sort((a, b) => b.mass - a.mass);
    this.leaderboard = arr.slice(0, 6).map(p => [p.id, p.name, Math.round(p.mass)]);
  }

  // ---- Snapshots -----------------------------------------------------------
  broadcast(events) {
    const w = this.world;
    for (const v of this.viewers.values()) {
      const p = w.players.get(v.id);
      if (!p || !p.alive) continue;
      const vw = viewWidth(p.mass) * (1 + C.AOI_MARGIN);
      const vh = vw * 0.75;
      const x0 = p.cx - vw / 2, x1 = p.cx + vw / 2, y0 = p.cy - vh / 2, y1 = p.cy + vh / 2;
      const q = w.queryBox(x0, y0, x1, y1, this._q);

      const cells = new Array(q.cells.length * 6);
      let k = 0;
      const pl = {};
      for (const c of q.cells) {
        cells[k++] = c.id; cells[k++] = c.owner; cells[k++] = Math.round(c.x); cells[k++] = Math.round(c.y);
        cells[k++] = Math.round(c.mass * 10) / 10; cells[k++] = c.mergeAt > w.time ? 1 : 0;
        const last = v.metaSent.get(c.owner);
        if (last === undefined || w.tick - last >= C.META_EVERY_TICKS) {
          const op = w.players.get(c.owner);
          if (op) {
            pl[c.owner] = [op.name, op.skin, Math.round(op.mult * 100) / 100, w.time < op.spawnProtUntil ? 1 : 0, op.extractT > 0 ? 1 : 0];
            v.metaSent.set(c.owner, w.tick);
          }
        }
      }
      // Pellets: delta vs what this viewer already knows.
      const seen = new Set();
      const pa = [];
      for (const pel of q.pellets) {
        seen.add(pel.id);
        if (!v.knownPellets.has(pel.id)) { v.knownPellets.add(pel.id); pa.push(pel.id, Math.round(pel.x), Math.round(pel.y), pel.c); }
      }
      const pr = [];
      for (const id of v.knownPellets) if (!seen.has(id)) { pr.push(id); v.knownPellets.delete(id); }

      const ej = new Array(q.ejected.length * 5);
      k = 0;
      for (const e of q.ejected) { ej[k++] = e.id; ej[k++] = Math.round(e.x); ej[k++] = Math.round(e.y); ej[k++] = e.mass; ej[k++] = e.c; }

      const ev = [];
      for (const e of events) {
        if (e.p === v.id || e.v === v.id) { ev.push(e); continue; }
        if (e.x !== undefined && e.x >= x0 && e.x <= x1 && e.y >= y0 && e.y <= y1) ev.push(e);
      }

      const msg = {
        t: 'snap', tk: w.tick, ts: Math.round(w.time * 1000),
        me: {
          m: Math.round(p.mass * 10) / 10, mult: p.mult, seq: p.lastSeq,
          ring: p.extractRing, ext: p.extractRing >= 0 ? Math.min(1, p.extractT / C.EXTRACT_SECONDS) : 0,
          prot: w.time < p.spawnProtUntil ? Math.max(0, p.spawnProtUntil - w.time) : 0,
          kills: p.kills, peak: Math.round(p.peakMass), alive: this.aliveCount(),
          cap: C.MULT_CAP + Math.min(C.STREAK_MAX, p.streak) * C.STREAK_CAP_BONUS,
          t: Math.round(w.time - p.joinedAt),
        },
        c: cells, e: ej, pa, pr, pl,
        rg: w.rings.map(r => [r.channelers, Math.round(r.bestProgress * 100) / 100]),
        ev,
      };
      if (w.tick - v.lastLbTick >= 20) { msg.lb = this.leaderboard; v.lastLbTick = w.tick; }
      this.send(v.id, msg);
    }
  }
}
