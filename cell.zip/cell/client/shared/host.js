// CELL — GameHost: accounts + rooms + session protocol. Host-agnostic.
// The Node server wraps WebSockets as `conn` objects; the browser's offline
// mode wraps an in-memory pipe. Either way this file owns ALL bank mutations.
//
// conn interface: { send(obj), close(), token?, session? }
// storage interface: { async get(token) -> acct|null, async set(token, acct) }
import { CONFIG as C } from './config.js';
import { Room } from './room.js';
import { newAccount, applyDailyAllowance, enterRound, settleExtraction, settleDeath, accountView, isValidRisk, unlockedSkinCount, tierFor } from './economy.js';
import { cleanName } from './profanity.js';

const TOKEN_RE = /^[A-Za-z0-9_-]{8,64}$/;

export class GameHost {
  constructor({ storage, now = () => Date.now(), log = () => {} }) {
    this.storage = storage;
    this.now = now;
    this.log = log;
    this.rooms = new Map();          // roomId -> Room
    this.sessions = new Map();       // token -> session
    this.byPlayer = new Map();       // `${roomId}:${playerId}` -> session
    this._timer = null;
    for (const tier of Object.keys(C.LOBBIES)) this.createRoom(tier);
  }

  // ---- lifecycle -----------------------------------------------------------
  startLoop(setIntervalFn = setInterval) {
    if (this._timer) return;
    let last = this.now();
    let acc = 0;
    const step = 1000 / C.TICK_RATE;
    this._timer = setIntervalFn(() => {
      const t = this.now();
      acc += t - last; last = t;
      if (acc > step * 5) acc = step * 5; // don't spiral after a tab sleeps
      while (acc >= step) { acc -= step; this.tickAll(); }
    }, step / 2);
  }
  stopLoop(clearIntervalFn = clearInterval) { if (this._timer) { clearIntervalFn(this._timer); this._timer = null; } }

  tickAll() {
    for (const room of this.rooms.values()) room.tick();
    // Prune spare empty rooms (keep one per tier alive so joins are instant).
    if ((this.rooms.size > 2)) {
      const perTier = {};
      for (const r of this.rooms.values()) perTier[r.tier] = (perTier[r.tier] || 0) + 1;
      for (const [id, r] of this.rooms) {
        if (r.humanCount() === 0 && perTier[r.tier] > 1) { this.rooms.delete(id); perTier[r.tier]--; }
      }
    }
  }

  createRoom(tier) {
    const room = new Room({
      tier,
      send: (pid, msg) => this.sendToPlayer(room, pid, msg),
      onResult: (pid, result) => this.onResult(room, pid, result),
    });
    this.rooms.set(room.id, room);
    return room;
  }

  findRoom(tier) {
    for (const r of this.rooms.values()) if (r.tier === tier && !r.isFull()) return r;
    return this.createRoom(tier);
  }

  // ---- messaging -----------------------------------------------------------
  sendToPlayer(room, pid, msg) {
    const s = this.byPlayer.get(`${room.id}:${pid}`);
    if (s && s.conn) s.conn.send(msg);
  }

  async handle(conn, msg) {
    if (!msg || typeof msg !== 'object') return;
    try {
      switch (msg.t) {
        case 'hello': return await this.onHello(conn, msg);
        case 'ping': return conn.send({ t: 'pong', c: msg.c, ts: this.now() });
      }
      const s = conn.session;
      if (!s) return conn.send({ t: 'err', code: 'nohello', msg: 'Say hello first' });
      switch (msg.t) {
        case 'join': return await this.onJoin(s, msg);
        case 'in': return this.onInput(s, msg);
        case 'leave': return this.onLeave(s);
        case 'name': { s.name = cleanName(msg.name); return conn.send({ t: 'name', name: s.name }); }
        case 'skin': return await this.onSkin(s, msg);
        case 'ad': return await this.onAd(s, msg);
        default: return conn.send({ t: 'err', code: 'unknown', msg: 'Unknown message' });
      }
    } catch (e) {
      this.log('handle error', e);
      conn.send({ t: 'err', code: 'server', msg: 'Something went wrong' });
    }
  }

  async onHello(conn, msg) {
    const token = typeof msg.token === 'string' && TOKEN_RE.test(msg.token) ? msg.token : null;
    if (!token) return conn.send({ t: 'err', code: 'token', msg: 'Bad token', fatal: true });
    let s = this.sessions.get(token);
    if (s && s.conn && s.conn !== conn) {
      // One active session per token: kick the old connection.
      try { s.conn.send({ t: 'kicked', msg: 'Signed in elsewhere' }); s.conn.close(); } catch (_) {}
      s.conn = null;
    }
    if (!s) {
      let acct = await this.storage.get(token);
      if (!acct) acct = newAccount(this.now());
      s = { token, acct, conn: null, name: 'cell', playerId: null, roomId: null, stake: 0, inputTokens: C.INPUT_RATE, inputStamp: this.now(), pendingResult: null };
      this.sessions.set(token, s);
    }
    s.conn = conn; conn.session = s; conn.token = token;
    if (typeof msg.name === 'string') s.name = cleanName(msg.name);
    const allowance = applyDailyAllowance(s.acct, this.now());
    if (allowance) await this.storage.set(token, s.acct);
    conn.send({ t: 'welcome', name: s.name, account: accountView(s.acct), allowance, config: publicConfig(), serverTime: this.now() });
    if (s.pendingResult) { conn.send(s.pendingResult); s.pendingResult = null; }
    // Reconnect into a live round.
    if (s.roomId !== null) {
      const room = this.rooms.get(s.roomId);
      if (room && room.hasPlayer(s.playerId)) room.resendJoin(s.playerId);
      else { s.roomId = null; s.playerId = null; }
    }
  }

  async onJoin(s, msg) {
    if (s.roomId !== null) return s.conn.send({ t: 'err', code: 'inround', msg: 'Already in a round' });
    const risk = Number(msg.risk);
    if (!isValidRisk(risk)) return s.conn.send({ t: 'err', code: 'risk', msg: 'Pick a valid risk' });
    const { stake, tier } = enterRound(s.acct, risk);
    await this.storage.set(s.token, s.acct);
    const room = this.findRoom(tier);
    const pid = room.join({ name: s.name, skin: s.acct.skin, stake, streak: s.acct.streak });
    s.roomId = room.id; s.playerId = pid; s.stake = stake; s.risk = risk;
    this.byPlayer.set(`${room.id}:${pid}`, s);
    s.conn.send({ t: 'account', account: accountView(s.acct) });
    // Room.join already queued the 'joined' message via sendToPlayer — but the byPlayer
    // mapping did not exist at that moment, so resend it now.
    room.resendJoin(pid);
  }

  onInput(s, msg) {
    if (s.roomId === null) return;
    // Token bucket: INPUT_RATE per second, burst of INPUT_RATE.
    const now = this.now();
    s.inputTokens = Math.min(C.INPUT_RATE, s.inputTokens + (now - s.inputStamp) / 1000 * C.INPUT_RATE);
    s.inputStamp = now;
    if (s.inputTokens < 1) return;
    s.inputTokens -= 1;
    const room = this.rooms.get(s.roomId);
    if (!room) return;
    room.input(s.playerId, { x: +msg.x, y: +msg.y, split: !!msg.s, eject: !!msg.e, seq: (msg.q | 0) });
  }

  onLeave(s) {
    if (s.roomId === null) return;
    const room = this.rooms.get(s.roomId);
    if (room) room.leave(s.playerId, 'left');
  }

  async onSkin(s, msg) {
    const skin = msg.skin | 0;
    if (skin < 0 || skin >= unlockedSkinCount(s.acct)) return s.conn.send({ t: 'err', code: 'skin', msg: 'Skin locked' });
    s.acct.skin = skin;
    await this.storage.set(s.token, s.acct);
    s.conn.send({ t: 'account', account: accountView(s.acct) });
  }

  // Rewarded-ad hooks. Disabled unless CONFIG.ADS_ENABLED; the host still
  // enforces daily caps so a tampered client cannot farm them.
  async onAd(s, msg) {
    if (!C.ADS_ENABLED) return s.conn.send({ t: 'err', code: 'ads', msg: 'Not available' });
    const day = new Date(this.now()).toISOString().slice(0, 10);
    if (s.acct.adDay !== day) { s.acct.adDay = day; s.acct.adAllowance = 0; s.acct.adReenter = 0; }
    if (msg.kind === 'allowance' && s.acct.adAllowance < C.AD_EXTRA_ALLOWANCE_PER_DAY) {
      s.acct.adAllowance++;
      s.acct.bank += C.DAILY_ALLOWANCE;
    } else if (msg.kind === 'reenter' && s.acct.adReenter < C.AD_REENTER_PER_DAY && s.lastLoss > 0) {
      s.acct.adReenter++;
      s.acct.bank += Math.floor(s.lastLoss * C.AD_REENTER_REFUND);
      s.lastLoss = 0;
    } else return s.conn.send({ t: 'err', code: 'ads', msg: 'Not available' });
    await this.storage.set(s.token, s.acct);
    s.conn.send({ t: 'account', account: accountView(s.acct) });
  }

  onResult(room, pid, result) {
    const key = `${room.id}:${pid}`;
    const s = this.byPlayer.get(key);
    this.byPlayer.delete(key);
    if (!s) return;
    let settled;
    if (result.kind === 'extract') settled = settleExtraction(s.acct, result.stake, result.mult);
    else { settled = settleDeath(s.acct, result.stake, result.kills); s.lastLoss = result.stake; }
    s.roomId = null; s.playerId = null; s.stake = 0;
    const msg = { t: 'result', result: { ...result, ...settled }, account: accountView(s.acct) };
    this.storage.set(s.token, s.acct).catch?.(() => {});
    if (s.conn) s.conn.send(msg); else s.pendingResult = msg;
  }

  disconnect(conn) {
    const s = conn.session;
    if (!s || s.conn !== conn) return;
    s.conn = null;
    // If not in a round, drop the session from memory (account is persisted).
    if (s.roomId === null) this.sessions.delete(s.token);
    // Otherwise the player keeps living; the AFK rule (60s without input) forfeits.
  }
}

function publicConfig() {
  return {
    riskTiers: C.RISK_TIERS, minStake: C.MIN_STAKE, floor: C.BANK_FLOOR, dailyAllowance: C.DAILY_ALLOWANCE,
    lobbies: C.LOBBIES, milestones: C.SKIN_MILESTONES, multCap: C.MULT_CAP, streakMax: C.STREAK_MAX,
    streakPayoutBonus: C.STREAK_PAYOUT_BONUS, streakCapBonus: C.STREAK_CAP_BONUS, adsEnabled: C.ADS_ENABLED,
  };
}
export { tierFor };
