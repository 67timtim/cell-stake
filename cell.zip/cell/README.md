# CELL

Browser arena game (agar.io genre) with one twist: before you enter, you **risk** a slice of your persistent **Bank** of mass, and you must physically **extract** (hold a gold ring for 3 s) to keep `Risk × multiplier`. Die and the stake is gone. Nothing is purchasable, transferable or cashable — banked mass is earned in-game only.

```
cell/
├─ client/                 static site (Cloudflare Pages publishes this folder)
│  ├─ index.html, style.css
│  ├─ js/                  main.js (app shell), game.js (round client), render.js, input.js,
│  │                       audio.js, net.js (Ws/Local transports), storage.js, skins.js, ads.js
│  └─ shared/              code shared with the server (imported by both)
│     ├─ config.js         ★ ALL gameplay constants live here
│     ├─ sim.js            World: cells, pellets, eat/split/eject, decay, multiplier, extraction
│     ├─ bots.js           bot AI + names
│     ├─ room.js           Room = World + bots + per-viewer AOI snapshots
│     ├─ economy.js        Bank / stake / payout / streak / allowance math
│     ├─ host.js           GameHost: sessions, accounts, rooms, protocol (owns all bank mutations)
│     └─ profanity.js
├─ server/                 Node authoritative server (ws) — index.js, storage.js
├─ test/                   suite.js (runs in Node and browser), run.js, index.html
├─ package.json, Dockerfile, fly.toml
```

**Why `client/shared/`?** The authoritative simulation, the room/snapshot logic and the account/bank rules are one code path used by both the Node server (`server/index.js` imports `../client/shared/*`) and the browser. When no server is reachable the client runs the identical `GameHost` in-page as an **offline practice arena** (same rules, same bots, Bank kept in `localStorage`). This is also how the game is developed and tested without a server.

## Run locally

Client only (offline mode, no Node needed):

```bash
cd cell && python3 -m http.server 5173
```
Open http://localhost:5173/client/ — after ~2.5 s of “connecting…” it falls back to OFFLINE (chip in the menu).

Server + client:

```bash
cd cell && npm install && npm run dev      # SERVE_CLIENT=1 node server/index.js  →  http://localhost:8080
```
Or run the server alone (`npm start`, port 8080) and the static client from any host; the client tries `ws://localhost:8080/ws` when served from localhost.

Tests:

```bash
npm test                                   # node --test test/   (20 tests: sim, economy, room, host/protocol, perf)
```
or open http://localhost:5173/test/index.html in a browser.

## Deploy

**Client → Cloudflare Pages.** Framework preset: none. Build command: (empty). Output directory: `cell/client`. Set the server URL in `client/js/serverConfig.js` (`SERVER_URL = 'wss://your-server.example/ws'`) or leave empty and pass `?server=wss://…` while testing. Without a reachable server the site still works in offline mode.

**Server → Railway.** New service from repo, root `cell/`. Start command `npm start`. Env vars below. Add a volume mounted at `/data` and set `DATA_FILE=/data/accounts.json` so accounts survive redeploys.

**Server → Fly.io.** `fly launch --no-deploy` (uses `fly.toml` + `Dockerfile`), `fly volumes create cell_data --size 1`, `fly deploy`.

Env vars:

| var | default | meaning |
|---|---|---|
| `PORT` | `8080` | listen port (`/ws` for WebSocket, `/health` JSON) |
| `DATA_FILE` | `server/data/accounts.json` | JSON account store (debounced writes, atomic rename) |
| `SERVE_CLIENT` | unset | `1` = also serve `client/` as static files (single-service deploy) |
| `ALLOWED_ORIGINS` | *(any)* | comma-separated allowed `Origin` values for the WebSocket |

## Tuning

Everything numeric is in [`client/shared/config.js`](client/shared/config.js): map size, tick rate, pellet count, speed curve, eat ratio/gain, split/eject/merge, decay, camera, Bank/allowance/floor, risk tiers & lobbies, multiplier rates & cap, rings & extraction time, streak bonuses, spawn protection, AFK, bots, networking, portal-ad hooks. The server and client must be deployed from the same config.

## Protocol (client → server → client)

Client sends only: `hello{token,name}`, `join{risk}`, `in{q,x,y,s?,e?}` (≤30/s, server rate-limits), `leave`, `name`, `skin`, `ping`, `ad{kind}`.
Server sends: `welcome{account,config,allowance}`, `account`, `joined{id,stake,tier,rings,…}`, `snap{…}` (viewport + 20 % only; pellets as add/remove deltas; player metadata every 0.5 s), `result{result,account}`, `err`, `kicked`, `pong`.

Bank mutations happen only inside `shared/host.js` on the server (enter, extract, death, daily allowance, ad hooks). The client has no message that can set bank, mass or multiplier; tests in `test/suite.js` cover tampered messages, invalid risk, locked skins, input flooding, double-join and reconnect.

## Client architecture notes

- Canvas 2D, single draw loop, camera-box culling, pellets batched by colour, one cached sprite per skin (no per-frame gradients), particle pool, DOM HUD updated at 10 Hz.
- Interpolation: entities rendered ~100 ms behind the newest snapshot; local cells are led along the current input by `interp + rtt/2` and smoothed against server corrections (snap on >120 units).
- Offline fallback: `LocalTransport` runs `GameHost` in-page with `LocalAccountStore` (localStorage). Online, the account only ever comes from the server.
- Persistence seam: `client/js/storage.js` (client) and `server/storage.js` (server) — swap for CrazyGames cloud save / SQLite without touching game code.
- Ads seam: `client/js/ads.js` `NoopAds`; hooks (extra allowance, re-enter with 25 % back) are wired in menu/result but disabled by `CONFIG.ADS_ENABLED=false` and capped server-side.
- Mobile: left-half joystick, 76 px Split/Eject buttons, safe-area insets, `touch-action:none`, gestures blocked. Quality toggle caps DPR at 1.

## Status vs. spec

Built: arena rules, stake layer (Bank, risk tiers, lobbies, multiplier, rings, streaks, mercy floor, allowance), bots (server-side, unlabeled), authoritative server with AOI snapshots + reconnect + AFK + one-session-per-token, skins by milestone, stats, settings, pause/leave, 3-panel how-to on first launch, profanity filter, procedural SFX, favicon, mobile controls, tests, deploy files.

Not built (out of scope per spec): viruses, accounts, chat, parties, global leaderboards, real SDK integration. Delta compression of snapshots was skipped (pellets already delta-encoded; cell arrays are small).
